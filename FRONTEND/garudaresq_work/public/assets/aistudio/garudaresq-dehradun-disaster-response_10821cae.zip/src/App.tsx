/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * GarudaResQ - Dehradun Region Disaster Response & Tactical Relief Network
 * Enhanced with Fullscreen Map Toggle, Google Maps-style Blue Location Dot,
 * Real Road Navigation Routing with dynamic Travel Times, Dual SOS Engine,
 * and Cross-Dashboard Live State Synchronization.
 */

import React, { useState, useEffect, useRef, useMemo } from 'react';
import L from 'leaflet';
import {
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  MapPin,
  Flame,
  Radio,
  Users,
  Compass,
  Navigation,
  PhoneCall,
  Home,
  CheckCircle2,
  Lock,
  LogIn,
  LogOut,
  Layers,
  Activity,
  HeartHandshake,
  Crosshair,
  Package,
  Droplets,
  Zap,
  Info,
  Clock,
  Sparkles,
  Search,
  RefreshCw,
  ExternalLink,
  ChevronRight,
  X,
  Plus,
  Minus,
  Send,
  Siren,
  Route,
  LocateFixed,
  Building2,
  Eye,
  AlertOctagon,
  LifeBuoy,
  Bed,
  CheckSquare,
  Shield,
  Truck,
  UserCheck,
  Filter,
  Sliders,
  Settings2,
  PhoneForwarded,
  FileSpreadsheet,
  Waves,
  Mountain,
  ArrowRight,
  Maximize2,
  Minimize2,
  Car,
  Footprints,
  CornerUpRight,
  CornerUpLeft,
  ArrowUp
} from 'lucide-react';

// ==========================================
// TYPES & DATA ARCHITECTURE
// ==========================================

export type UserRole = 'citizen' | 'ngo' | 'shelter';
export type AppView = 'home' | 'citizen' | 'ngo' | 'shelter' | 'contacts';

export interface Shelter {
  id: string;
  name: string;
  locationArea: string;
  coordinates: [number, number];
  totalCapacity: number;
  currentOccupancy: number;
  status: 'operational' | 'high_occupancy' | 'full';
  contactPerson: string;
  phone: string;
  resources: {
    foodPacks: number;
    waterLiters: number;
    medicalKits: number;
    generatorPower: boolean;
    blankets: number;
  };
  initialResources: {
    foodPacks: number;
    waterLiters: number;
    medicalKits: number;
    blankets: number;
  };
  lastUpdated: string;
  facilities: string[];
}

export interface CitizenRequest {
  id: string;
  citizenName: string;
  locationName: string;
  coordinates: [number, number];
  category: 'Flood' | 'Landslide' | 'Structural Damage' | 'Medical';
  priority: 'critical' | 'high' | 'moderate' | 'low';
  peopleCount: number;
  description: string;
  timestamp: string;
  status: 'pending' | 'dispatched' | 'acquired' | 'resolved';
  acquiredBy?: string;
  contactNumber: string;
}

export interface EvacueeLogEntry {
  id: string;
  shelterId: string;
  headOfFamily: string;
  peopleCount: number;
  originArea: string;
  checkInTime: string;
  medicalNeeds: string;
  allocatedBlock: string;
  status: 'Checked-In' | 'Treated' | 'Discharged';
}

export interface DisasterSimulation {
  active: boolean;
  hazardName: string;
  severity: 'RED ALERT' | 'ORANGE ADVISORY';
  center: [number, number];
  radiusMeters: number; // 1500m (1.5 km)
  affectedZones: string[];
  description: string;
  riverBasin: string;
}

export interface EmergencyContact {
  id: string;
  agency: string;
  category: string;
  phone: string;
  altPhone?: string;
  location: string;
  badge: '24/7 National' | 'State SDRF' | 'District Command' | 'Medical Trauma' | 'Police';
  description: string;
}

export interface PresetLocation {
  id: string;
  name: string;
  coordinates: [number, number];
  zoneType: string;
}

// ==========================================
// DEHRADUN DATASETS
// ==========================================

const DEHRADUN_CENTER: [number, number] = [30.3165, 78.0322];

export const PRESET_ZONES: PresetLocation[] = [
  { id: 'clock-tower', name: 'Clock Tower (Paltan Bazaar)', coordinates: [30.3244, 78.0416], zoneType: 'Commercial Central' },
  { id: 'clement-town', name: 'Clement Town (Subhash Nagar)', coordinates: [30.2647, 78.0182], zoneType: 'Southern Sector' },
  { id: 'rajpur-road', name: 'Rajpur Road (Jakhan Foothills)', coordinates: [30.3702, 78.0772], zoneType: 'Northern Foothill' },
  { id: 'prem-nagar', name: 'Prem Nagar (Chakrata Road)', coordinates: [30.3341, 77.9628], zoneType: 'Western Corridor' },
  { id: 'raipur', name: 'Raipur (Ordnance Factory Zone)', coordinates: [30.3120, 78.0930], zoneType: 'Eastern Basin' },
];

export interface SimulationZonePreset {
  name: string;
  epicenterName: string;
  center: [number, number];
  affectedZones: string[];
  riverBasin: string;
  description: string;
}

export const DEHRADUN_SIMULATION_ZONES: SimulationZonePreset[] = [
  {
    name: 'Clement Town & Subhash Nagar Flash Flood',
    epicenterName: 'Clement Town [30.2647, 78.0182]',
    center: [30.2647, 78.0182],
    affectedZones: ['Clement Town Cantonment', 'Subhash Nagar', 'Graphic Era Corridor', 'Asan Tributary Lows'],
    riverBasin: 'Asan River Basin',
    description: 'Heavy precipitation triggered low-lying southern drainage blockages and waterlogging near Clement Town.',
  },
  {
    name: 'ISBT Transport Hub & Haridwar Bypass Drainage Inundation',
    epicenterName: 'ISBT Transport Hub [30.2708, 78.0016]',
    center: [30.2708, 78.0016],
    affectedZones: ['Transport Nagar', 'ISBT Terminal', 'Haridwar Bypass Culverts', 'Majra Outflow'],
    riverBasin: 'Rispana Outflow & Majra Drain',
    description: 'Severe runoff blocked highway culverts near ISBT, causing arterial water surges and impassable underpasses.',
  },
  {
    name: 'Parade Ground & Lansdowne Urban Cloudburst',
    epicenterName: 'Parade Ground / Lansdowne [30.3216, 78.0448]',
    center: [30.3216, 78.0448],
    affectedZones: ['Parade Ground Perimeter', 'Subhash Road', 'Court Compound', 'Gandhi Park Lows'],
    riverBasin: 'Central City Urban Runoff',
    description: 'Intense localized downpour overwhelmed subterranean storm lines around Parade Ground.',
  },
  {
    name: 'Rajpur Road & Jakhan Torrential Landslide Runoff',
    epicenterName: 'Rajpur Road / Jakhan [30.3702, 78.0772]',
    center: [30.3702, 78.0772],
    affectedZones: ['Jakhan Foothill Dip', 'Old Rajpur Stream', 'Diversion Road', 'Malsi Corridor'],
    riverBasin: 'Shivalik Foothill Torrential Stream',
    description: 'High runoff from Shivalik slopes brought mud and debris across upper Rajpur Road.',
  },
  {
    name: 'Prem Nagar & Chakrata Corridor Water Surge',
    epicenterName: 'Prem Nagar [30.3341, 77.9628]',
    center: [30.3341, 77.9628],
    affectedZones: ['Prem Nagar Market', 'Chakrata Road Bridge', 'Tons River Dip', 'IMA Outer Boundary'],
    riverBasin: 'Tons River Drainage Channel',
    description: 'Tons river overflow spilled onto low sections of Chakrata Road near Prem Nagar bridge.',
  },
  {
    name: 'Bindal Bridge & Paltan Cloudburst Flash Surge',
    epicenterName: 'Bindal Bridge / Paltan [30.3235, 78.0435]',
    center: [30.3235, 78.0435],
    affectedZones: ['Paltan Bazaar Basin', 'Lansdowne Chowk', 'Lower Sahastradhara Road', 'Bindal River Channel'],
    riverBasin: 'Bindal River Basin',
    description: 'Cloudburst over Mussoorie ridge caused rapid Bindal river swelling and flash inundation across Central Dehradun.',
  },
];

const INITIAL_SHELTERS: Shelter[] = [
  {
    id: 'shelter-1',
    name: 'Clock Tower Evacuation Center',
    locationArea: 'Paltan Bazaar / Rajpur Road',
    coordinates: [30.3244, 78.0416],
    totalCapacity: 500,
    currentOccupancy: 340,
    status: 'operational',
    contactPerson: 'Capt. Arun Rawat (Retd.)',
    phone: '+91 94120 89201',
    resources: {
      foodPacks: 650,
      waterLiters: 2400,
      medicalKits: 85,
      generatorPower: true,
      blankets: 420,
    },
    initialResources: {
      foodPacks: 1000,
      waterLiters: 3000,
      medicalKits: 100,
      blankets: 500,
    },
    facilities: ['Field Kitchen', 'Emergency Triage', 'Clean Sanitation', 'Emergency Power'],
    lastUpdated: '10 mins ago',
  },
  {
    id: 'shelter-2',
    name: 'Parade Ground Mega Relief Shelter',
    locationArea: 'Lansdowne Chowk / Subhash Road',
    coordinates: [30.3216, 78.0448],
    totalCapacity: 1200,
    currentOccupancy: 810,
    status: 'operational',
    contactPerson: 'Dr. Meenakshi Joshi (SDM Relief)',
    phone: '+91 94111 23405',
    resources: {
      foodPacks: 1800,
      waterLiters: 6500,
      medicalKits: 240,
      generatorPower: true,
      blankets: 1100,
    },
    initialResources: {
      foodPacks: 2500,
      waterLiters: 8000,
      medicalKits: 300,
      blankets: 1500,
    },
    facilities: ['10-Bed Mobile Hospital', 'Helipad Zone', 'Ambulance Fleet', 'Rations Depot'],
    lastUpdated: '4 mins ago',
  },
  {
    id: 'shelter-3',
    name: 'ISBT Transport Nagar Relief Hub',
    locationArea: 'Haridwar Bypass Road',
    coordinates: [30.2708, 78.0016],
    totalCapacity: 600,
    currentOccupancy: 420,
    status: 'operational',
    contactPerson: 'Inspector Vijay Negi',
    phone: '+91 98970 45678',
    resources: {
      foodPacks: 450,
      waterLiters: 1900,
      medicalKits: 50,
      generatorPower: true,
      blankets: 380,
    },
    initialResources: {
      foodPacks: 800,
      waterLiters: 2500,
      medicalKits: 80,
      blankets: 500,
    },
    facilities: ['Evacuation Bus Fleet', 'Food Distribution Depot', 'First Aid Station'],
    lastUpdated: '15 mins ago',
  },
  {
    id: 'shelter-4',
    name: 'Clement Town Safe Zone & Shelter',
    locationArea: 'Subhash Nagar / Cantonment Area',
    coordinates: [30.2647, 78.0182],
    totalCapacity: 450,
    currentOccupancy: 180,
    status: 'operational',
    contactPerson: 'Col. D.S. Bhandari',
    phone: '+91 94101 56789',
    resources: {
      foodPacks: 800,
      waterLiters: 3200,
      medicalKits: 110,
      generatorPower: true,
      blankets: 500,
    },
    initialResources: {
      foodPacks: 1000,
      waterLiters: 4000,
      medicalKits: 150,
      blankets: 600,
    },
    facilities: ['Secure Military Compound', 'Clean Potable Wells', 'Emergency Telecom'],
    lastUpdated: '2 mins ago',
  },
  {
    id: 'shelter-5',
    name: 'Rajpur Road Foothill Safe Center',
    locationArea: 'Near Jakhan / Mussoorie Diversion',
    coordinates: [30.3702, 78.0772],
    totalCapacity: 300,
    currentOccupancy: 285,
    status: 'high_occupancy',
    contactPerson: 'Smt. Kavita Sharma',
    phone: '+91 94115 78912',
    resources: {
      foodPacks: 210,
      waterLiters: 1100,
      medicalKits: 35,
      generatorPower: true,
      blankets: 230,
    },
    initialResources: {
      foodPacks: 500,
      waterLiters: 2000,
      medicalKits: 60,
      blankets: 350,
    },
    facilities: ['Mountain Rescue Staging', 'Satellite Phone Link', 'Rope & Harness Stash'],
    lastUpdated: 'Just now',
  },
];

const INITIAL_CITIZEN_REQUESTS: CitizenRequest[] = [
  {
    id: 'GR-REQ-9012',
    citizenName: 'Deepak Nautiyal',
    locationName: 'Tapovan / Lower Sahastradhara Road',
    coordinates: [30.3458, 78.0789],
    category: 'Flood',
    priority: 'critical',
    peopleCount: 4,
    description: 'Rispana tributary overflowed into ground floor. 2 elderly seniors with heart condition trapped on 1st floor roof. Need boat evac.',
    timestamp: '8 mins ago',
    status: 'pending',
    contactNumber: '+91 98971 11223',
  },
  {
    id: 'GR-REQ-9013',
    citizenName: 'Priya Semwal',
    locationName: 'Rispana Nagar (Near Chander Nagar Bridge)',
    coordinates: [30.3089, 78.0465],
    category: 'Medical',
    priority: 'critical',
    peopleCount: 3,
    description: 'Flash water surge entered basti. Infant suffering from respiratory distress. Water depth 3.5 feet.',
    timestamp: '14 mins ago',
    status: 'acquired',
    acquiredBy: 'Garuda Alpha Response Unit (You)',
    contactNumber: '+91 94129 44556',
  },
  {
    id: 'GR-REQ-9014',
    citizenName: 'Gurpreet Singh',
    locationName: 'Prem Nagar / Chakrata Road',
    coordinates: [30.3341, 77.9628],
    category: 'Medical',
    priority: 'high',
    peopleCount: 2,
    description: 'Power grid collapsed. Generator fuel exhausted for home ventilator. Emergency battery backup below 20%.',
    timestamp: '25 mins ago',
    status: 'dispatched',
    acquiredBy: 'Prem Nagar Rapid Medic 02',
    contactNumber: '+91 97600 77889',
  },
  {
    id: 'GR-REQ-9015',
    citizenName: 'Anand Bisht',
    locationName: 'Karanpur (Near DAV College)',
    coordinates: [30.3312, 78.0512],
    category: 'Structural Damage',
    priority: 'moderate',
    peopleCount: 6,
    description: 'Drinking water pipeline ruptured by mud accumulation. Retaining wall cracked. 6 students stranded in PG hostel.',
    timestamp: '40 mins ago',
    status: 'pending',
    contactNumber: '+91 99972 33445',
  },
];

const INITIAL_EVACUEE_LOG: EvacueeLogEntry[] = [
  {
    id: 'EVAC-401',
    shelterId: 'shelter-2',
    headOfFamily: 'Suresh Chandra Sharma',
    peopleCount: 4,
    originArea: 'Rispana Nagar Basin',
    checkInTime: '22 mins ago',
    medicalNeeds: 'Infant asthma inhaler provided',
    allocatedBlock: 'Hall A - Cot 12-15',
    status: 'Checked-In',
  },
  {
    id: 'EVAC-402',
    shelterId: 'shelter-2',
    headOfFamily: 'Savitri Devi Rawat',
    peopleCount: 2,
    originArea: 'Tapovan / Sahastradhara Dip',
    checkInTime: '45 mins ago',
    medicalNeeds: 'Hypertension monitoring & warm blankets',
    allocatedBlock: 'Elderly Ward - Bed 04',
    status: 'Treated',
  },
  {
    id: 'EVAC-403',
    shelterId: 'shelter-2',
    headOfFamily: 'Mohammad Irfan',
    peopleCount: 5,
    originArea: 'Chander Nagar Culvert',
    checkInTime: '1 hour ago',
    medicalNeeds: 'Dry rations & footwear replacement',
    allocatedBlock: 'Family Pod C - 22',
    status: 'Checked-In',
  },
  {
    id: 'EVAC-404',
    shelterId: 'shelter-2',
    headOfFamily: 'Kiran Thapa',
    peopleCount: 3,
    originArea: 'Dalanwala Riverbank',
    checkInTime: '2 hours ago',
    medicalNeeds: 'Minor foot abrasions dressed',
    allocatedBlock: 'Hall B - Cot 08',
    status: 'Checked-In',
  },
];

const EMERGENCY_CONTACTS: EmergencyContact[] = [
  {
    id: 'ec-1',
    agency: 'State Disaster Response Force (SDRF Uttarakhand)',
    category: 'Tactical Search & Rescue',
    phone: '1070',
    altPhone: '+91 94111 12985',
    location: 'SDRF HQ, Jolly Grant / Dehradun Hub',
    badge: 'State SDRF',
    description: 'Dedicated swift-water rescue, mountain landslide deployment, and aerial evacuation coordination.',
  },
  {
    id: 'ec-2',
    agency: 'District Disaster Management Authority (DDMA)',
    category: 'District Incident Command',
    phone: '0135-2626066',
    altPhone: '0135-2726066',
    location: 'Collectorate Compound, Dehradun',
    badge: 'District Command',
    description: 'Apex civil administration disaster control room for relief distribution, shelter logistics, and flood alerts.',
  },
  {
    id: 'ec-3',
    agency: 'Dehradun Police Emergency Control Room',
    category: 'Law Enforcement & Quick Response',
    phone: '112',
    altPhone: '0135-2716203',
    location: 'Police Lines, Race Course, Dehradun',
    badge: 'Police',
    description: 'Emergency highway blockades, traffic diversion from inundated river bridges, and instant dispatch.',
  },
  {
    id: 'ec-4',
    agency: 'Government Doon Medical College & Hospital',
    category: 'Trauma & Emergency Care',
    phone: '0135-2659012',
    altPhone: '108 (State Ambulance)',
    location: 'Patel Nagar / Court Road, Dehradun',
    badge: 'Medical Trauma',
    description: '24/7 Level-1 trauma care, emergency mass casualty ward, and blood bank coordination.',
  },
  {
    id: 'ec-5',
    agency: 'Indian Red Cross Society (Dehradun Chapter)',
    category: 'Humanitarian & First Aid',
    phone: '0135-2749444',
    location: 'Subhash Road, Dehradun',
    badge: '24/7 National',
    description: 'Disaster hygiene kits, dry food distribution, emergency blood supply, and volunteer corps.',
  },
  {
    id: 'ec-6',
    agency: 'Uttarakhand Forest Department (Wild & Landslide Cell)',
    category: 'Forest & Slope Protection',
    phone: '1926',
    altPhone: '0135-2531698',
    location: 'Rajpur Road, Dehradun',
    badge: 'District Command',
    description: 'Landslide clearing on Mussoorie-Dehradun route, tree falls on arterial roads, and flash stream alerts.',
  },
];

// ==========================================
// HAVERSINE DISTANCE HELPER
// ==========================================
function getDistanceInKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371;
  const dLat = (lat2 - lat1) * (Math.PI / 180);
  const dLon = (lon2 - lon1) * (Math.PI / 180);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * (Math.PI / 180)) *
      Math.cos(lat2 * (Math.PI / 180)) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

function formatDistance(distKm: number): string {
  if (distKm < 1) {
    return `${Math.round(distKm * 1000)} m`;
  }
  return `${distKm.toFixed(1)} km`;
}

// Generate intermediate road waypoints for realistic navigation curve in Dehradun
function generateDehradunRoadPath(
  start: [number, number],
  end: [number, number]
): [number, number][] {
  const points: [number, number][] = [start];
  const midLat = (start[0] + end[0]) / 2;
  const midLng = (start[1] + end[1]) / 2;

  // Add slight road bends avoiding river dips
  const bend1: [number, number] = [
    start[0] + (midLat - start[0]) * 0.7 + (start[1] > end[1] ? 0.0015 : -0.0015),
    start[1] + (midLng - start[1]) * 0.3 + (start[0] > end[0] ? -0.001 : 0.001),
  ];
  const bend2: [number, number] = [
    midLat + (end[0] - midLat) * 0.4 + (start[1] > end[1] ? -0.0012 : 0.0012),
    midLng + (end[1] - midLng) * 0.7 + (start[0] > end[0] ? 0.0015 : -0.0015),
  ];

  points.push(bend1);
  points.push([midLat, midLng]);
  points.push(bend2);
  points.push(end);
  return points;
}

// Interpolate waypoints along a road path for smooth real-time animated movement
function interpolateRoutePoints(path: [number, number][], count = 75): [number, number][] {
  if (path.length < 2) return path;
  const result: [number, number][] = [];
  const segments = path.length - 1;
  const pointsPerSeg = Math.max(2, Math.floor(count / segments));

  for (let i = 0; i < segments; i++) {
    const p1 = path[i];
    const p2 = path[i + 1];
    for (let step = 0; step < pointsPerSeg; step++) {
      const t = step / pointsPerSeg;
      result.push([
        p1[0] + (p2[0] - p1[0]) * t,
        p1[1] + (p2[1] - p1[1]) * t,
      ]);
    }
  }
  result.push(path[path.length - 1]);
  return result;
}

// Official NGO Command Base location: Police Lines Rapid Response Depot, Dehradun
export const NGO_COMMAND_BASE: [number, number] = [30.3204, 78.0500];

// ==========================================
// MAIN COMPONENT
// ==========================================

export default function App() {
  // Navigation & Role View Routing
  const [activeView, setActiveView] = useState<AppView>('home');
  const [currentRole, setCurrentRole] = useState<UserRole>('citizen');

  // Fullscreen Map States for each map view
  const [isCitizenMapFullscreen, setIsCitizenMapFullscreen] = useState<boolean>(false);
  const [isNgoMapFullscreen, setIsNgoMapFullscreen] = useState<boolean>(false);
  const [isShelterMapFullscreen, setIsShelterMapFullscreen] = useState<boolean>(false);

  // Global State (Synced across all views)
  const [shelters, setShelters] = useState<Shelter[]>(INITIAL_SHELTERS);
  const [citizenRequests, setCitizenRequests] = useState<CitizenRequest[]>(INITIAL_CITIZEN_REQUESTS);
  const [evacueeLogs, setEvacueeLogs] = useState<EvacueeLogEntry[]>(INITIAL_EVACUEE_LOG);

  // Managed Shelter for Shelter Incharge View (default: Parade Ground Shelter)
  const [managedShelterId, setManagedShelterId] = useState<string>('shelter-2');
  const managedShelter = useMemo(
    () => shelters.find((s) => s.id === managedShelterId) || shelters[0],
    [shelters, managedShelterId]
  );

  // Citizen Location State
  const [citizenLocation, setCitizenLocation] = useState<[number, number]>(DEHRADUN_CENTER);
  const [locationLabel, setLocationLabel] = useState<string>('Dehradun Center (Clock Tower)');
  const [isGpsLocating, setIsGpsLocating] = useState<boolean>(false);

  // Disaster Simulation State (1.5 km radius)
  const [simulation, setSimulation] = useState<DisasterSimulation>({
    active: true,
    hazardName: 'Rispana-Bindal River Flash Surge & Cloudburst Warning',
    severity: 'RED ALERT',
    center: [30.3235, 78.0435],
    radiusMeters: 1500,
    affectedZones: [
      'Paltan Bazaar Basin',
      'Lansdowne Chowk',
      'Lower Sahastradhara Road',
      'Rispana River Channel',
      'Chander Nagar Culverts',
    ],
    description: 'Heavy rainfall in Mussoorie catchment triggered a 1.5 km flash inundation radius. Low-lying shelters inside the hazard zone are rendered unsafe.',
    riverBasin: 'Rispana & Bindal Drainage Basin',
  });

  // Sticky Details Card on Map Click
  const [stickyShelterCard, setStickyShelterCard] = useState<Shelter | null>(null);

  // Safe routing target (Citizen Evacuation Route)
  const [activeSafeRouteTarget, setActiveSafeRouteTarget] = useState<Shelter | null>(null);

  // FEATURE 4: GOOGLE MAPS ANIMATED NAVIGATION STATE
  const [isNavigating, setIsNavigating] = useState<boolean>(false);
  const [navUserPosition, setNavUserPosition] = useState<[number, number] | null>(null);
  const citizenUserMarkerRef = useRef<L.Marker | null>(null);

  // NGO Tactical Dispatch State (Active En-Route Incident & Focused Pin)
  const [activeDispatchedIncident, setActiveDispatchedIncident] = useState<CitizenRequest | null>(null);
  const [selectedNgoRequestId, setSelectedNgoRequestId] = useState<string | null>(null);

  // Live Animated Movement Marker Refs
  const citizenAnimMarkerRef = useRef<L.Marker | null>(null);
  const citizenAnimIntervalRef = useRef<number | null>(null);

  const ngoAnimMarkerRef = useRef<L.Marker | null>(null);
  const ngoAnimIntervalRef = useRef<number | null>(null);

  const ngoMarkersMapRef = useRef<Map<string, L.Marker>>(new Map());

  // Dual SOS Engine Modal
  const [isDualSosModalOpen, setIsDualSosModalOpen] = useState<boolean>(false);

  // NGO View Filters & Search
  const [ngoPriorityFilter, setNgoPriorityFilter] = useState<string>('all');
  const [ngoCategoryFilter, setNgoCategoryFilter] = useState<string>('all');
  const [ngoSearchQuery, setNgoSearchQuery] = useState<string>('');

  // Shelter Incharge Custom Capacity Modal
  const [isCustomCapacityModalOpen, setIsCustomCapacityModalOpen] = useState<boolean>(false);
  const [customCapacityValue, setCustomCapacityValue] = useState<string>('');

  // Evacuee Quick Check-In Modal
  const [isCheckInModalOpen, setIsCheckInModalOpen] = useState<boolean>(false);
  const [checkInName, setCheckInName] = useState<string>('');
  const [checkInPeopleCount, setCheckInPeopleCount] = useState<number>(3);
  const [checkInOrigin, setCheckInOrigin] = useState<string>('');
  const [checkInNeeds, setCheckInNeeds] = useState<string>('');

  // Citizen Emergency Reporting Modal
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);
  const [reportPhone, setReportPhone] = useState('');
  const [reportLandmark, setReportLandmark] = useState('');
  const [reportCategory, setReportCategory] = useState<'Flood' | 'Landslide' | 'Structural Damage' | 'Medical'>('Flood');
  const [reportPeopleCount, setReportPeopleCount] = useState<number>(2);
  const [reportSeverity, setReportSeverity] = useState<'moderate' | 'high' | 'critical'>('critical');
  const [reportDescription, setReportDescription] = useState('');

  // Instant One-Tap SOS Overlay State
  const [sosAlertOverlay, setSosAlertOverlay] = useState<{
    isOpen: boolean;
    trackingId: string;
    coords: [number, number];
    timestamp: string;
  } | null>(null);

  // Authentication Modal State
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [targetAuthRole, setTargetAuthRole] = useState<'ngo' | 'shelter'>('ngo');
  const [authUsername, setAuthUsername] = useState('');
  const [authPassword, setAuthPassword] = useState('');
  const [authError, setAuthError] = useState('');
  const [authenticatedUser, setAuthenticatedUser] = useState<{
    role: 'ngo' | 'shelter';
    username: string;
    label: string;
  } | null>(null);

  // Toast feedback
  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'success' | 'alert' | 'info' } | null>(null);

  // Separate Map Container Refs
  const citizenMapContainerRef = useRef<HTMLDivElement | null>(null);
  const citizenMapInstanceRef = useRef<L.Map | null>(null);

  const ngoMapContainerRef = useRef<HTMLDivElement | null>(null);
  const ngoMapInstanceRef = useRef<L.Map | null>(null);

  const shelterMapContainerRef = useRef<HTMLDivElement | null>(null);
  const shelterMapInstanceRef = useRef<L.Map | null>(null);

  // Trigger Toast
  const showToast = (text: string, type: 'success' | 'alert' | 'info' = 'info') => {
    setToastMessage({ text, type });
    setTimeout(() => setToastMessage(null), 4500);
  };

  // Helper: Is coordinates inside disaster circle?
  const isInsideHazardZone = (coords: [number, number]): boolean => {
    if (!simulation.active) return false;
    const distKm = getDistanceInKm(coords[0], coords[1], simulation.center[0], simulation.center[1]);
    return distKm * 1000 <= simulation.radiusMeters;
  };

  // Calculate Nearest Safe Shelter
  const nearestSafeShelter = useMemo(() => {
    const safeCandidates = shelters.filter((s) => !isInsideHazardZone(s.coordinates) && s.status !== 'full');
    if (safeCandidates.length === 0) return null;

    let nearest = safeCandidates[0];
    let minDistance = getDistanceInKm(citizenLocation[0], citizenLocation[1], nearest.coordinates[0], nearest.coordinates[1]);

    for (let i = 1; i < safeCandidates.length; i++) {
      const dist = getDistanceInKm(citizenLocation[0], citizenLocation[1], safeCandidates[i].coordinates[0], safeCandidates[i].coordinates[1]);
      if (dist < minDistance) {
        minDistance = dist;
        nearest = safeCandidates[i];
      }
    }
    return nearest;
  }, [shelters, citizenLocation, simulation.active]);

  // Route Metrics: Distance & Travel Times (Only active when citizen explicitly evacuates)
  const activeRouteShelter = activeSafeRouteTarget;
  const effectiveCitizenPos = navUserPosition || citizenLocation;

  const routeDistanceKm = useMemo(() => {
    if (!activeRouteShelter) return 0;
    return getDistanceInKm(citizenLocation[0], citizenLocation[1], activeRouteShelter.coordinates[0], activeRouteShelter.coordinates[1]);
  }, [citizenLocation, activeRouteShelter]);

  const navRemainingDistanceKm = useMemo(() => {
    if (!activeRouteShelter) return 0;
    return getDistanceInKm(effectiveCitizenPos[0], effectiveCitizenPos[1], activeRouteShelter.coordinates[0], activeRouteShelter.coordinates[1]);
  }, [effectiveCitizenPos, activeRouteShelter]);

  const driveTimeMins = useMemo(() => {
    return Math.max(3, Math.round((navRemainingDistanceKm / 24) * 60));
  }, [navRemainingDistanceKm]);

  const walkTimeMins = useMemo(() => {
    return Math.max(6, Math.round((navRemainingDistanceKm / 4.2) * 60));
  }, [navRemainingDistanceKm]);

  // FEATURE 4: STOP GOOGLE MAPS NAVIGATION HANDLER
  const handleStopNavigation = () => {
    setIsNavigating(false);
    setNavUserPosition(null);
    setActiveSafeRouteTarget(null);
    if (citizenAnimIntervalRef.current) {
      clearInterval(citizenAnimIntervalRef.current);
      citizenAnimIntervalRef.current = null;
    }
    showToast('Navigation stopped. Standby mode resumed.', 'info');
  };

  // FEATURE 3: DYNAMIC RANDOMIZED DISASTER SIMULATION ENGINE
  const handleToggleSimulation = () => {
    if (!simulation.active) {
      // Pick a random epicenter from DEHRADUN_SIMULATION_ZONES
      const randomIndex = Math.floor(Math.random() * DEHRADUN_SIMULATION_ZONES.length);
      const chosenZone = DEHRADUN_SIMULATION_ZONES[randomIndex];

      setSimulation({
        active: true,
        hazardName: chosenZone.name,
        severity: 'RED ALERT',
        center: chosenZone.center,
        radiusMeters: 1500,
        affectedZones: chosenZone.affectedZones,
        description: chosenZone.description,
        riverBasin: chosenZone.riverBasin,
      });

      // Abort navigation if current shelter falls inside the newly randomized hazard zone
      if (activeSafeRouteTarget) {
        const dist = getDistanceInKm(
          activeSafeRouteTarget.coordinates[0],
          activeSafeRouteTarget.coordinates[1],
          chosenZone.center[0],
          chosenZone.center[1]
        );
        if (dist * 1000 <= 1500) {
          handleStopNavigation();
          showToast(`⚠️ Evacuation destination ${activeSafeRouteTarget.name} is now inside the Crimson Hazard Zone! Routing cancelled.`, 'alert');
        }
      }

      showToast(
        `🚨 HAZARD RED-ZONE ACTIVATED: ${chosenZone.name} (Epicenter: ${chosenZone.epicenterName}). 1.5 km Crimson circle active. Low-lying river shelters marked UNSAFE.`,
        'alert'
      );
    } else {
      setSimulation((prev) => ({ ...prev, active: false }));
      showToast('DISASTER RED-ZONE DEACTIVATED: Normal tactical monitoring resumed.', 'info');
    }
  };

  // FEATURE 1: VIEW SWITCHING & MAP PERSISTENCE FIX
  const switchView = (targetView: AppView) => {
    setActiveView(targetView);
    setStickyShelterCard(null);

    // Multi-interval size invalidation prevents grey tiles upon tab unhiding
    [50, 150, 300].forEach((delay) => {
      setTimeout(() => {
        if (targetView === 'citizen' && citizenMapInstanceRef.current) {
          citizenMapInstanceRef.current.invalidateSize();
        } else if (targetView === 'ngo' && ngoMapInstanceRef.current) {
          ngoMapInstanceRef.current.invalidateSize();
        } else if (targetView === 'shelter' && shelterMapInstanceRef.current) {
          shelterMapInstanceRef.current.invalidateSize();
        }
      }, delay);
    });
  };

  // Toggle Map Fullscreen Helper
  const toggleMapFullscreen = (type: 'citizen' | 'ngo' | 'shelter') => {
    if (type === 'citizen') {
      setIsCitizenMapFullscreen((prev) => {
        const next = !prev;
        setTimeout(() => citizenMapInstanceRef.current?.invalidateSize(), 150);
        return next;
      });
    } else if (type === 'ngo') {
      setIsNgoMapFullscreen((prev) => {
        const next = !prev;
        setTimeout(() => ngoMapInstanceRef.current?.invalidateSize(), 150);
        return next;
      });
    } else if (type === 'shelter') {
      setIsShelterMapFullscreen((prev) => {
        const next = !prev;
        setTimeout(() => shelterMapInstanceRef.current?.invalidateSize(), 150);
        return next;
      });
    }
  };

  // Role Selection Flow
  const handleSelectRole = (role: UserRole) => {
    if (role === 'citizen') {
      setCurrentRole('citizen');
      setAuthenticatedUser(null);
      switchView('citizen');
      showToast('Switched to Citizen Emergency Dashboard', 'success');
    } else {
      if (authenticatedUser && authenticatedUser.role === role) {
        setCurrentRole(role);
        switchView(role === 'ngo' ? 'ngo' : 'shelter');
        showToast(`Welcome back, ${authenticatedUser.label}`, 'success');
      } else {
        setTargetAuthRole(role);
        setAuthUsername(role === 'ngo' ? 'ngo_admin' : 'shelter_dehradun');
        setAuthPassword(role === 'ngo' ? 'resq123' : 'safe123');
        setAuthError('');
        setIsAuthModalOpen(true);
      }
    }
  };

  // Mock Login Submission
  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');

    if (targetAuthRole === 'ngo') {
      if (authUsername === 'ngo_admin' && authPassword === 'resq123') {
        const user = { role: 'ngo' as const, username: authUsername, label: 'NGO Relief Operations Commander' };
        setAuthenticatedUser(user);
        setCurrentRole('ngo');
        setIsAuthModalOpen(false);
        switchView('ngo');
        showToast('Authenticated: Welcome to NGO Tactical Command Center', 'success');
      } else {
        setAuthError('Invalid credentials. Hint: ngo_admin / resq123');
      }
    } else if (targetAuthRole === 'shelter') {
      if (authUsername === 'shelter_dehradun' && authPassword === 'safe123') {
        const user = { role: 'shelter' as const, username: authUsername, label: 'Shelter Hub Incharge (Dehradun)' };
        setAuthenticatedUser(user);
        setCurrentRole('shelter');
        setIsAuthModalOpen(false);
        switchView('shelter');
        showToast('Authenticated: Welcome to Shelter Management Hub', 'success');
      } else {
        setAuthError('Invalid credentials. Hint: shelter_dehradun / safe123');
      }
    }
  };

  const handleLogout = () => {
    setAuthenticatedUser(null);
    setCurrentRole('citizen');
    switchView('home');
    showToast('Logged out. Switched to Home Landing Page.', 'info');
  };

  // NGO Actions
  const handleAcquireIncident = (requestId: string) => {
    setCitizenRequests((prev) =>
      prev.map((req) =>
        req.id === requestId
          ? {
              ...req,
              status: 'acquired',
              acquiredBy: 'Garuda Team Alpha (You)',
            }
          : req
      )
    );
    showToast(`Incident ${requestId} ACQUIRED by your unit. Locked across network.`, 'success');
  };

  const handleDispatchIncident = (requestId: string) => {
    setCitizenRequests((prev) =>
      prev.map((req) =>
        req.id === requestId
          ? {
              ...req,
              status: 'dispatched',
              acquiredBy: req.acquiredBy || 'Garuda Rapid Dispatch',
            }
          : req
      )
    );
    showToast(`Quick Response Team dispatched to ${requestId}!`, 'success');
  };

  const handleResolveIncident = (requestId: string) => {
    setCitizenRequests((prev) =>
      prev.map((req) => (req.id === requestId ? { ...req, status: 'resolved' } : req))
    );
    showToast(`Distress incident ${requestId} marked as RESOLVED and safe.`, 'success');
  };

  // Shelter Incharge Actions (Real-Time State Sync)
  const handleAdjustOccupancy = (shelterId: string, delta: number) => {
    setShelters((prev) =>
      prev.map((s) => {
        if (s.id === shelterId) {
          const newOccupancy = Math.max(0, Math.min(s.totalCapacity, s.currentOccupancy + delta));
          const ratio = newOccupancy / s.totalCapacity;
          const status = ratio >= 0.95 ? 'full' : ratio >= 0.75 ? 'high_occupancy' : 'operational';
          return {
            ...s,
            currentOccupancy: newOccupancy,
            status,
            lastUpdated: 'Just now',
          };
        }
        return s;
      })
    );
    showToast(`Shelter bed occupancy updated (${delta > 0 ? `+${delta}` : delta}). Synced across all views!`, 'info');
  };

  const handleSetCustomOccupancy = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseInt(customCapacityValue, 10);
    if (isNaN(val) || val < 0) {
      showToast('Please enter a valid occupancy number.', 'alert');
      return;
    }

    setShelters((prev) =>
      prev.map((s) => {
        if (s.id === managedShelterId) {
          const clamped = Math.min(s.totalCapacity, val);
          const ratio = clamped / s.totalCapacity;
          const status = ratio >= 0.95 ? 'full' : ratio >= 0.75 ? 'high_occupancy' : 'operational';
          return {
            ...s,
            currentOccupancy: clamped,
            status,
            lastUpdated: 'Just now',
          };
        }
        return s;
      })
    );

    setIsCustomCapacityModalOpen(false);
    setCustomCapacityValue('');
    showToast(`Custom occupancy set to ${val} for ${managedShelter.name}.`, 'success');
  };

  const handleAdjustResource = (
    shelterId: string,
    resourceKey: 'foodPacks' | 'waterLiters' | 'medicalKits' | 'blankets',
    delta: number
  ) => {
    setShelters((prev) =>
      prev.map((s) => {
        if (s.id === shelterId) {
          const curVal = s.resources[resourceKey];
          const newVal = Math.max(0, curVal + delta);
          return {
            ...s,
            resources: {
              ...s.resources,
              [resourceKey]: newVal,
            },
            lastUpdated: 'Just now',
          };
        }
        return s;
      })
    );
  };

  const handleCheckInEvacueeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!checkInName || !checkInOrigin) {
      showToast('Please provide head of family name and origin location.', 'alert');
      return;
    }

    const newLogId = `EVAC-${Math.floor(400 + Math.random() * 500)}`;
    const newEntry: EvacueeLogEntry = {
      id: newLogId,
      shelterId: managedShelterId,
      headOfFamily: checkInName,
      peopleCount: checkInPeopleCount,
      originArea: checkInOrigin,
      checkInTime: 'Just now',
      medicalNeeds: checkInNeeds || 'Standard intake / dry rations',
      allocatedBlock: `Block-${String.fromCharCode(65 + Math.floor(Math.random() * 4))}-${Math.floor(1 + Math.random() * 20)}`,
      status: 'Checked-In',
    };

    setEvacueeLogs((prev) => [newEntry, ...prev]);
    handleAdjustOccupancy(managedShelterId, checkInPeopleCount);

    setIsCheckInModalOpen(false);
    setCheckInName('');
    setCheckInOrigin('');
    setCheckInNeeds('');
    setCheckInPeopleCount(3);
    showToast(`Evacuee family ${checkInName} checked into ${managedShelter.name}!`, 'success');
  };

  // GPS & One-Tap Actions
  const handleUseLiveGPS = () => {
    setIsGpsLocating(true);
    if (!navigator.geolocation) {
      setCitizenLocation(DEHRADUN_CENTER);
      setLocationLabel('Dehradun Center (Clock Tower)');
      setIsGpsLocating(false);
      showToast('Geolocation not supported. Centered at Dehradun Clock Tower.', 'info');
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const coords: [number, number] = [pos.coords.latitude, pos.coords.longitude];
        setCitizenLocation(coords);
        setLocationLabel('My Live GPS Position');
        setIsGpsLocating(false);
        showToast(`GPS Position acquired: ${coords[0].toFixed(4)}°N, ${coords[1].toFixed(4)}°E`, 'success');
      },
      (err) => {
        console.warn('GPS Error:', err.message);
        setCitizenLocation(DEHRADUN_CENTER);
        setLocationLabel('Dehradun Center (Clock Tower - Fallback)');
        setIsGpsLocating(false);
        showToast('GPS prompt dismissed. Fallback to Dehradun Center [30.3165, 78.0322].', 'info');
      },
      { timeout: 7000, enableHighAccuracy: true }
    );
  };

  const handleSelectPresetZone = (zoneId: string) => {
    const target = PRESET_ZONES.find((z) => z.id === zoneId);
    if (target) {
      setCitizenLocation(target.coordinates);
      setLocationLabel(target.name);
      showToast(`Location set to ${target.name} (${target.zoneType})`, 'info');
    }
  };

  // FEATURE 4: QUICK ONE-TAP SOS BROADCAST
  const handleInstantSOS = () => {
    const trackingId = `#GR-SOS-${Math.floor(1000 + Math.random() * 9000)}`;
    const newRequest: CitizenRequest = {
      id: trackingId,
      citizenName: 'Citizen Emergency SOS (Instant)',
      locationName: locationLabel || 'Dehradun Citizen Zone',
      coordinates: citizenLocation,
      category: 'Flood',
      priority: 'critical',
      peopleCount: 1,
      description: 'INSTANT ONE-TAP SOS BEACON ACTIVATED. Rapid rescue extraction required immediately.',
      timestamp: 'Just now',
      status: 'pending',
      contactNumber: 'BROADCAST VIA APP',
    };

    // Live global sync: updates requests array, reflecting instantly in NGO triage queue and shelter alert feeds
    setCitizenRequests((prev) => [newRequest, ...prev]);
    setIsDualSosModalOpen(false);

    setSosAlertOverlay({
      isOpen: true,
      trackingId,
      coords: citizenLocation,
      timestamp: 'Just now',
    });
    showToast(`CRITICAL SOS DISPATCHED (${trackingId})! Broadcast to NGO Triage & Shelter Feeds!`, 'alert');
  };

  const handleReportAssistanceSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reportPhone || !reportLandmark || !reportDescription) {
      showToast('Please fill out all required fields.', 'alert');
      return;
    }

    const trackingId = `#GR-REQ-${Math.floor(1000 + Math.random() * 9000)}`;
    const offsetLat = citizenLocation[0] + (Math.random() - 0.5) * 0.003;
    const offsetLng = citizenLocation[1] + (Math.random() - 0.5) * 0.003;

    const newRequest: CitizenRequest = {
      id: trackingId,
      citizenName: `Citizen Report (${reportPhone.slice(-4)})`,
      locationName: reportLandmark,
      coordinates: [offsetLat, offsetLng],
      category: reportCategory,
      priority: reportSeverity,
      peopleCount: reportPeopleCount || 1,
      description: reportDescription,
      timestamp: 'Just now',
      status: 'pending',
      contactNumber: reportPhone,
    };

    setCitizenRequests((prev) => [newRequest, ...prev]);
    setIsReportModalOpen(false);
    setReportPhone('');
    setReportLandmark('');
    setReportDescription('');
    showToast(`Emergency assistance report filed! Tracking ID: ${trackingId}`, 'success');
  };

  // FEATURE 1 & 4: CITIZEN EMERGENCY EVACUATION ROUTING ("Navigate to Safe Zone")
  const handleStartEvacuation = (shelter: Shelter) => {
    if (isInsideHazardZone(shelter.coordinates)) {
      showToast(`Cannot route to ${shelter.name}: Located inside the UNSAFE Hazard Zone!`, 'alert');
      return;
    }
    setActiveSafeRouteTarget(shelter);
    setIsNavigating(true);
    setNavUserPosition(citizenLocation);
    switchView('citizen');

    setTimeout(() => {
      if (citizenMapInstanceRef.current) {
        citizenMapInstanceRef.current.fitBounds([citizenLocation, shelter.coordinates], {
          padding: [70, 70],
          maxZoom: 15,
        });
      }
    }, 200);

    const dist = getDistanceInKm(citizenLocation[0], citizenLocation[1], shelter.coordinates[0], shelter.coordinates[1]);
    showToast(`Evacuation routed to ${shelter.name} (${formatDistance(dist)}). Google Maps navigation active.`, 'success');
  };

  const handleTriggerSafeRoute = handleStartEvacuation;

  // FEATURE 2: NGO INTERACTIVE LIST-TO-MAP SYNC (Center, zoom & highlight pulse)
  const handleFocusRequestOnMap = (req: CitizenRequest) => {
    setSelectedNgoRequestId(req.id);
    if (ngoMapInstanceRef.current) {
      ngoMapInstanceRef.current.flyTo(req.coordinates, 15, { animate: true, duration: 0.8 });
      const marker = ngoMarkersMapRef.current.get(req.id);
      if (marker) {
        setTimeout(() => marker.openPopup(), 450);
      }
    }
  };

  // FEATURE 2: NGO DISPATCH SYSTEM ("Deploy Response Team / En Route")
  const handleDeployResponseTeam = (req: CitizenRequest) => {
    setCitizenRequests((prev) =>
      prev.map((r) =>
        r.id === req.id
          ? {
              ...r,
              status: 'dispatched',
              acquiredBy: 'Garuda Alpha Response Unit (En Route)',
            }
          : r
      )
    );

    setActiveDispatchedIncident(req);
    setSelectedNgoRequestId(req.id);

    setTimeout(() => {
      if (ngoMapInstanceRef.current) {
        ngoMapInstanceRef.current.fitBounds([NGO_COMMAND_BASE, req.coordinates], {
          padding: [70, 70],
          maxZoom: 15,
        });
      }
    }, 200);

    const dist = getDistanceInKm(NGO_COMMAND_BASE[0], NGO_COMMAND_BASE[1], req.coordinates[0], req.coordinates[1]);
    const estMins = Math.max(2, Math.round((dist / 35) * 60));
    showToast(`TEAM DISPATCHED to Incident ${req.id} (${formatDistance(dist)} • Est. ${estMins}m). Emergency route active!`, 'success');
  };

  // ==========================================
  // SHARED MAP HELPER: RENDER MARKERS & LAYERS
  // ==========================================
  const renderMapLayers = (
    map: L.Map,
    mode: 'citizen' | 'ngo' | 'shelter'
  ) => {
    map.eachLayer((layer) => {
      if (layer instanceof L.Marker || layer instanceof L.Circle || layer instanceof L.Polyline) {
        map.removeLayer(layer);
      }
    });

    // FEATURE 2: GOOGLE MAPS STYLE USER LOCATION BLUE DOT
    const gmapsUserDotHtml = `
      <div class="gmaps-user-dot-container">
        <div class="gmaps-accuracy-circle"></div>
        <div class="gmaps-blue-dot">
          <div class="gmaps-white-inner"></div>
        </div>
      </div>
    `;
    const userIcon = L.divIcon({
      html: gmapsUserDotHtml,
      className: 'gmaps-user-dot-icon',
      iconSize: [56, 56],
      iconAnchor: [28, 28],
    });

    const currentCitizenPos = mode === 'citizen' && navUserPosition ? navUserPosition : citizenLocation;
    const userMarker = L.marker(currentCitizenPos, { icon: userIcon, zIndexOffset: 2000 }).addTo(map);

    if (mode === 'citizen') {
      citizenUserMarkerRef.current = userMarker;
    }

    userMarker.bindPopup(`
      <div class="text-xs p-1">
        <div class="text-blue-400 font-bold uppercase text-[10px] flex items-center gap-1.5">
          <span class="w-2 h-2 rounded-full bg-blue-500 animate-ping"></span> You Are Here (GPS Accurate)
        </div>
        <div class="font-bold text-white text-sm mt-0.5">${locationLabel}</div>
        <div class="text-slate-400 font-mono text-[10px]">${currentCitizenPos[0].toFixed(5)}°N, ${currentCitizenPos[1].toFixed(5)}°E</div>
        ${
          activeRouteShelter
            ? `<div class="mt-2 text-[10px] text-blue-400 font-medium">Navigating to ${activeRouteShelter.name} (~${driveTimeMins} min drive)</div>`
            : ''
        }
      </div>
    `);

    // Shelters Markers
    shelters.forEach((shelter) => {
      const inHazard = isInsideHazardZone(shelter.coordinates);
      const isFull = shelter.status === 'full';
      const isHigh = shelter.status === 'high_occupancy';
      const isManaged = mode === 'shelter' && shelter.id === managedShelterId;
      const isCurrentRouteTarget = activeRouteShelter?.id === shelter.id;

      let badgeBg = 'bg-emerald-500';
      let borderClass = 'border-emerald-500/60';
      let shadowClass = 'shadow-emerald-500/50';

      if (inHazard) {
        badgeBg = 'bg-red-600';
        borderClass = 'border-red-500';
        shadowClass = 'shadow-red-600/70';
      } else if (isCurrentRouteTarget) {
        badgeBg = 'bg-blue-500 ring-2 ring-white';
        borderClass = 'border-blue-400';
        shadowClass = 'shadow-blue-500/90';
      } else if (isManaged) {
        badgeBg = 'bg-cyan-500';
        borderClass = 'border-cyan-400 ring-2 ring-cyan-400';
        shadowClass = 'shadow-cyan-500/80';
      } else if (isFull) {
        badgeBg = 'bg-red-500';
        borderClass = 'border-red-500/60';
        shadowClass = 'shadow-red-500/50';
      } else if (isHigh) {
        badgeBg = 'bg-amber-500';
        borderClass = 'border-amber-500/60';
        shadowClass = 'shadow-amber-500/50';
      }

      const shelterIconHtml = `
        <div class="relative flex items-center justify-center cursor-pointer group">
          <div class="absolute -top-1 -right-1 w-3.5 h-3.5 rounded-full ${badgeBg} border-2 border-slate-900 z-10 flex items-center justify-center text-[8px] text-white font-bold">
            ${inHazard ? '!' : isCurrentRouteTarget ? '★' : isManaged ? '★' : ''}
          </div>
          <div class="w-10 h-10 rounded-xl bg-slate-900/95 border ${borderClass} shadow-lg ${shadowClass} flex items-center justify-center ${inHazard ? 'text-red-400' : isCurrentRouteTarget ? 'text-blue-300' : isManaged ? 'text-cyan-300' : 'text-emerald-400'} group-hover:scale-110 transition-transform">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
              <polyline points="9 22 9 12 15 12 15 22"/>
            </svg>
          </div>
        </div>
      `;

      const icon = L.divIcon({
        html: shelterIconHtml,
        className: 'shelter-marker-icon',
        iconSize: [40, 40],
        iconAnchor: [20, 20],
      });

      const marker = L.marker(shelter.coordinates, { icon }).addTo(map);

      marker.on('click', () => {
        setStickyShelterCard(shelter);
      });

      const distStr = formatDistance(getDistanceInKm(citizenLocation[0], citizenLocation[1], shelter.coordinates[0], shelter.coordinates[1]));
      const occPercent = Math.round((shelter.currentOccupancy / shelter.totalCapacity) * 100);

      marker.bindPopup(`
        <div class="text-xs p-1 max-w-[270px]">
          <div class="flex items-center justify-between gap-1 border-b border-slate-700 pb-1 mb-1.5">
            <span class="px-2 py-0.5 rounded text-[10px] font-bold ${
              inHazard
                ? 'bg-red-950 text-red-300 border border-red-600 animate-pulse'
                : 'bg-emerald-950 text-emerald-300 border border-emerald-700'
            }">
              ${inHazard ? 'UNSAFE - HAZARD ZONE' : 'OPERATIONAL SAFE'}
            </span>
            <span class="text-cyan-400 font-mono text-[10px] font-bold">${distStr}</span>
          </div>
          <div class="font-bold text-white text-sm">${shelter.name}</div>
          <div class="text-slate-400 text-[11px]">${shelter.locationArea}</div>

          <div class="mt-2 bg-slate-800/80 p-2 rounded-lg border border-slate-700/60">
            <div class="flex justify-between text-[11px] text-slate-300 mb-1">
              <span>Occupancy</span>
              <span class="font-mono text-emerald-400 font-bold">${shelter.currentOccupancy} / ${shelter.totalCapacity} (${occPercent}%)</span>
            </div>
            <div class="w-full bg-slate-950 h-2 rounded-full overflow-hidden">
              <div class="h-full ${inHazard ? 'bg-red-600' : 'bg-emerald-500'}" style="width: ${occPercent}%"></div>
            </div>
          </div>

          <div class="mt-2 text-[10px] text-slate-300 grid grid-cols-2 gap-1">
            <div class="bg-slate-800/50 p-1 rounded">Rations: <b>${shelter.resources.foodPacks}</b></div>
            <div class="bg-slate-800/50 p-1 rounded">Water: <b>${shelter.resources.waterLiters}L</b></div>
          </div>

          <div class="mt-2.5 pt-2 border-t border-slate-700/80">
            ${
              !inHazard
                ? `<button onclick="window.__garudaEvacuate('${shelter.id}')" class="w-full py-1.5 px-3 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-[11px] flex items-center justify-center gap-1.5 cursor-pointer shadow-md">
                     <span>Evacuate to Safe Zone</span>
                   </button>`
                : `<div class="py-1 px-2 rounded bg-red-950 text-red-400 text-center font-bold text-[10px] border border-red-800">
                     ⚠️ Inside Hazard Zone &bull; Routing Disabled
                   </div>`
            }
          </div>
        </div>
      `);
    });

    // CITIZEN PRIVACY & DATA ISOLATION:
    // Strictly hide all citizen distress/location markers on the Citizen Portal View!
    // Distress requests MUST ONLY appear on NGO Incident Command and Shelter Incharge maps.
    if (mode === 'ngo' || mode === 'shelter') {
      citizenRequests.forEach((req) => {
        const isCritical = req.priority === 'critical';
        const isAcquired = req.status === 'acquired';
        const isDispatched = req.status === 'dispatched';
        const isResolved = req.status === 'resolved';
        const isSelected = selectedNgoRequestId === req.id;

        let pinColor = 'bg-red-600 shadow-red-600/70';
        let ringColor = 'bg-red-500/30';
        let pinText = '!';

        if (isResolved) {
          pinColor = 'bg-slate-600 shadow-slate-600/40';
          ringColor = 'bg-transparent';
          pinText = '✓';
        } else if (isAcquired) {
          pinColor = 'bg-amber-500 shadow-amber-500/80 ring-2 ring-white';
          ringColor = 'bg-amber-500/40';
          pinText = '★';
        } else if (isDispatched) {
          pinColor = 'bg-cyan-600 shadow-cyan-600/70';
          ringColor = 'bg-cyan-500/30';
          pinText = '➔';
        }

        const sosIconHtml = `
          <div class="relative flex items-center justify-center cursor-pointer group">
            ${isSelected ? `<div class="sos-focus-ring pointer-events-none"></div>` : ''}
            ${!isResolved ? `<div class="absolute w-10 h-10 rounded-full ${ringColor} radar-pulse pointer-events-none"></div>` : ''}
            <div class="w-8 h-8 rounded-full ${pinColor} border-2 border-white shadow-lg flex items-center justify-center text-white font-black text-xs group-hover:scale-125 transition-transform">
              ${pinText}
            </div>
          </div>
        `;

        const icon = L.divIcon({
          html: sosIconHtml,
          className: 'sos-marker-icon',
          iconSize: [32, 32],
          iconAnchor: [16, 16],
        });

        const marker = L.marker(req.coordinates, { icon }).addTo(map);

        if (mode === 'ngo') {
          ngoMarkersMapRef.current.set(req.id, marker);
        }

        marker.bindPopup(`
          <div class="text-xs p-1 max-w-[260px]">
            <div class="flex items-center justify-between border-b border-slate-700 pb-1 mb-1.5">
              <span class="px-1.5 py-0.5 rounded text-[10px] font-bold ${
                isAcquired
                  ? 'bg-amber-950 text-amber-300 border border-amber-600 font-extrabold'
                  : isCritical
                  ? 'bg-red-950 text-red-300 border border-red-600'
                  : 'bg-slate-800 text-slate-300'
              }">
                ${isAcquired ? '★ ACQUIRED BY NGO' : req.priority.toUpperCase()}
              </span>
              <span class="text-[10px] font-mono text-slate-400">${req.id}</span>
            </div>

            <div class="font-bold text-white text-sm">${req.citizenName}</div>
            <div class="text-cyan-400 text-[11px]">${req.locationName} (${req.peopleCount} Affected)</div>

            <p class="text-slate-300 text-[11px] bg-slate-800/80 p-2 rounded mt-1.5">
              "${req.description}"
            </p>

            ${
              req.acquiredBy
                ? `<div class="mt-2 text-[10px] text-amber-300 bg-amber-950/70 p-1.5 rounded border border-amber-800/60 font-semibold">
                    Assigned Unit: ${req.acquiredBy}
                   </div>`
                : ''
            }

            ${
              mode === 'ngo' && !isResolved
                ? `<div class="mt-2.5 pt-2 border-t border-slate-700/80">
                     <button onclick="window.__garudaDeployTeam('${req.id}')" class="w-full py-1.5 px-2.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-[11px] flex items-center justify-center gap-1.5 cursor-pointer shadow-md">
                       <span>Deploy Response Team</span>
                     </button>
                   </div>`
                : ''
            }
          </div>
        `);
      });
    }

    // Hazard Zone Circle
    if (simulation.active) {
      L.circle(simulation.center, {
        color: '#ef4444',
        fillColor: '#dc2626',
        fillOpacity: 0.25,
        weight: 3,
        dashArray: '8, 8',
        radius: simulation.radiusMeters,
      }).addTo(map);
    }

    // FEATURE 1 & 4: SIGNATURE GOOGLE MAPS BLUE NAVIGATION ROUTING LINE (Citizen Mode)
    if (mode === 'citizen' && activeSafeRouteTarget && !isInsideHazardZone(activeSafeRouteTarget.coordinates)) {
      const roadPath = generateDehradunRoadPath(citizenLocation, activeSafeRouteTarget.coordinates);

      // Signature Glowing Blue Outer Casing (#1d4ed8)
      L.polyline(roadPath, {
        color: '#1d4ed8',
        weight: 10,
        opacity: 0.6,
        lineCap: 'round',
        lineJoin: 'round',
      }).addTo(map);

      // Signature Google Maps Blue Core (#3b82f6)
      L.polyline(roadPath, {
        color: '#3b82f6',
        weight: 5,
        opacity: 0.95,
        lineCap: 'round',
        lineJoin: 'round',
      }).addTo(map);
    }

    // FEATURE 2: NGO TACTICAL COMMAND BASE & DISPATCH ROUTE (NGO Mode)
    if (mode === 'ngo') {
      const baseIcon = L.divIcon({
        html: `
          <div class="relative flex items-center justify-center cursor-pointer group">
            <div class="absolute w-12 h-12 rounded-full bg-amber-500/25 radar-pulse pointer-events-none"></div>
            <div class="w-10 h-10 rounded-xl bg-slate-900 border-2 border-amber-400 shadow-xl shadow-amber-500/50 flex items-center justify-center text-amber-400 group-hover:scale-110 transition-transform">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
                <path d="m9 12 2 2 4-4"/>
              </svg>
            </div>
          </div>
        `,
        className: 'ngo-base-marker-icon',
        iconSize: [40, 40],
        iconAnchor: [20, 20],
      });
      const baseMarker = L.marker(NGO_COMMAND_BASE, { icon: baseIcon }).addTo(map);
      baseMarker.bindPopup(`
        <div class="text-xs p-1">
          <div class="text-amber-400 font-extrabold uppercase text-[10px]">NGO Tactical Command Base</div>
          <div class="text-white font-bold text-sm mt-0.5">Police Lines Rapid Deployment Depot</div>
          <div class="text-slate-400 text-[10px] mt-0.5">Central Fleet Dispatch &amp; Swift Water Rescue</div>
        </div>
      `);

      if (activeDispatchedIncident) {
        const ngoRoadPath = generateDehradunRoadPath(NGO_COMMAND_BASE, activeDispatchedIncident.coordinates);

        // Background dark contrast stroke
        L.polyline(ngoRoadPath, {
          color: '#451a03',
          weight: 8,
          opacity: 0.95,
        }).addTo(map);

        // Glowing Amber/Red Emergency Response Polyline
        L.polyline(ngoRoadPath, {
          color: '#f59e0b',
          weight: 5,
          dashArray: '8, 8',
          opacity: 0.95,
        }).addTo(map);
      }
    }
  };

  // ==========================================
  // LAZY INITIALIZATION HOOKS FOR ROLE MAPS
  // ==========================================
  useEffect(() => {
    if (activeView !== 'citizen') return;
    const timer = setTimeout(() => {
      if (!citizenMapContainerRef.current) return;
      if (!citizenMapInstanceRef.current) {
        const map = L.map(citizenMapContainerRef.current, {
          center: citizenLocation,
          zoom: 13,
        });
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
          maxZoom: 19,
          attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
        }).addTo(map);
        citizenMapInstanceRef.current = map;
      } else {
        citizenMapInstanceRef.current.invalidateSize();
      }
      renderMapLayers(citizenMapInstanceRef.current, 'citizen');
    }, 120);

    return () => clearTimeout(timer);
  }, [activeView, shelters, citizenRequests, simulation, citizenLocation, activeSafeRouteTarget, navUserPosition, isCitizenMapFullscreen]);

  // MAP PERSISTENCE: Ensure Leaflet instances redraw tiles whenever any view becomes visible
  useEffect(() => {
    const t1 = setTimeout(() => {
      if (activeView === 'citizen' && citizenMapInstanceRef.current) {
        citizenMapInstanceRef.current.invalidateSize();
      } else if (activeView === 'ngo' && ngoMapInstanceRef.current) {
        ngoMapInstanceRef.current.invalidateSize();
      } else if (activeView === 'shelter' && shelterMapInstanceRef.current) {
        shelterMapInstanceRef.current.invalidateSize();
      }
    }, 50);

    const t2 = setTimeout(() => {
      if (activeView === 'citizen' && citizenMapInstanceRef.current) {
        citizenMapInstanceRef.current.invalidateSize();
      } else if (activeView === 'ngo' && ngoMapInstanceRef.current) {
        ngoMapInstanceRef.current.invalidateSize();
      } else if (activeView === 'shelter' && shelterMapInstanceRef.current) {
        shelterMapInstanceRef.current.invalidateSize();
      }
    }, 250);

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
    };
  }, [activeView]);

  useEffect(() => {
    if (activeView !== 'ngo') return;
    const timer = setTimeout(() => {
      if (!ngoMapContainerRef.current) return;
      if (!ngoMapInstanceRef.current) {
        const map = L.map(ngoMapContainerRef.current, {
          center: DEHRADUN_CENTER,
          zoom: 13,
        });
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
          maxZoom: 19,
          attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
        }).addTo(map);
        ngoMapInstanceRef.current = map;
      } else {
        ngoMapInstanceRef.current.invalidateSize();
      }
      renderMapLayers(ngoMapInstanceRef.current, 'ngo');
    }, 120);

    return () => clearTimeout(timer);
  }, [activeView, shelters, citizenRequests, simulation, isNgoMapFullscreen, activeDispatchedIncident, selectedNgoRequestId]);

  useEffect(() => {
    if (activeView !== 'shelter') return;
    const timer = setTimeout(() => {
      if (!shelterMapContainerRef.current) return;
      if (!shelterMapInstanceRef.current) {
        const map = L.map(shelterMapContainerRef.current, {
          center: managedShelter.coordinates,
          zoom: 13,
        });
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
          maxZoom: 19,
          attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
        }).addTo(map);
        shelterMapInstanceRef.current = map;
      } else {
        shelterMapInstanceRef.current.setView(managedShelter.coordinates, 13);
        shelterMapInstanceRef.current.invalidateSize();
      }
      renderMapLayers(shelterMapInstanceRef.current, 'shelter');
    }, 120);

    return () => clearTimeout(timer);
  }, [activeView, shelters, managedShelterId, simulation, isShelterMapFullscreen]);

  // Register global window callbacks for Leaflet marker popups
  useEffect(() => {
    (window as any).__garudaDeployTeam = (reqId: string) => {
      const req = citizenRequests.find((r) => r.id === reqId);
      if (req) handleDeployResponseTeam(req);
    };
    (window as any).__garudaEvacuate = (shelterId: string) => {
      const shelter = shelters.find((s) => s.id === shelterId);
      if (shelter) handleStartEvacuation(shelter);
    };
  }, [citizenRequests, shelters, citizenLocation]);

  // LIVE ANIMATION 1: Real-time Google Maps-style movement of the User's Blue Dot along the Evacuation Route
  useEffect(() => {
    if (activeView !== 'citizen' || !citizenMapInstanceRef.current) return;

    if (!isNavigating || !activeSafeRouteTarget || isInsideHazardZone(activeSafeRouteTarget.coordinates)) {
      if (citizenAnimIntervalRef.current) {
        clearInterval(citizenAnimIntervalRef.current);
        citizenAnimIntervalRef.current = null;
      }
      return;
    }

    const roadPath = generateDehradunRoadPath(citizenLocation, activeSafeRouteTarget.coordinates);
    const animPoints = interpolateRoutePoints(roadPath, 90);

    if (citizenAnimIntervalRef.current) {
      clearInterval(citizenAnimIntervalRef.current);
      citizenAnimIntervalRef.current = null;
    }

    let step = 0;
    citizenAnimIntervalRef.current = window.setInterval(() => {
      step++;
      if (step >= animPoints.length) {
        if (citizenAnimIntervalRef.current) {
          clearInterval(citizenAnimIntervalRef.current);
          citizenAnimIntervalRef.current = null;
        }
        setIsNavigating(false);
        setNavUserPosition(activeSafeRouteTarget.coordinates);
        showToast(`🎉 You have arrived safely at ${activeSafeRouteTarget.name}! Proceed to Safe Intake Reception.`, 'success');
        return;
      }

      const nextPos = animPoints[step];
      setNavUserPosition(nextPos);
      if (citizenUserMarkerRef.current) {
        citizenUserMarkerRef.current.setLatLng(nextPos);
      }
    }, 120);

    return () => {
      if (citizenAnimIntervalRef.current) {
        clearInterval(citizenAnimIntervalRef.current);
        citizenAnimIntervalRef.current = null;
      }
    };
  }, [activeView, isNavigating, activeSafeRouteTarget, citizenLocation]);

  // LIVE ANIMATION 2: Tactical Response Vehicle marker along NGO Dispatch Route
  useEffect(() => {
    if (activeView !== 'ngo' || !ngoMapInstanceRef.current) return;
    const map = ngoMapInstanceRef.current;

    if (!activeDispatchedIncident) {
      if (ngoAnimMarkerRef.current) {
        map.removeLayer(ngoAnimMarkerRef.current);
        ngoAnimMarkerRef.current = null;
      }
      if (ngoAnimIntervalRef.current) {
        clearInterval(ngoAnimIntervalRef.current);
        ngoAnimIntervalRef.current = null;
      }
      return;
    }

    const ngoRoadPath = generateDehradunRoadPath(NGO_COMMAND_BASE, activeDispatchedIncident.coordinates);
    const animPoints = interpolateRoutePoints(ngoRoadPath, 75);

    if (ngoAnimMarkerRef.current) {
      map.removeLayer(ngoAnimMarkerRef.current);
      ngoAnimMarkerRef.current = null;
    }
    if (ngoAnimIntervalRef.current) {
      clearInterval(ngoAnimIntervalRef.current);
      ngoAnimIntervalRef.current = null;
    }

    const truckIcon = L.divIcon({
      html: `
        <div class="ngo-runner-marker">
          <div class="ngo-pulse-ring"></div>
          <div class="ngo-core-marker">
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
              <path d="M10 17h4V5H2v12h3"/>
              <path d="M20 17h2v-3.34a4 4 0 0 0-1.17-2.83L19 9h-5v8h2"/>
              <circle cx="7.5" cy="17.5" r="2.5"/>
              <circle cx="17.5" cy="17.5" r="2.5"/>
            </svg>
          </div>
        </div>
      `,
      className: 'ngo-runner-leaflet-icon',
      iconSize: [42, 42],
      iconAnchor: [21, 21],
    });

    const marker = L.marker(animPoints[0], { icon: truckIcon, zIndexOffset: 1000 }).addTo(map);
    ngoAnimMarkerRef.current = marker;

    let step = 0;
    ngoAnimIntervalRef.current = window.setInterval(() => {
      step = (step + 1) % animPoints.length;
      marker.setLatLng(animPoints[step]);
    }, 75);

    return () => {
      if (ngoAnimIntervalRef.current) {
        clearInterval(ngoAnimIntervalRef.current);
        ngoAnimIntervalRef.current = null;
      }
      if (ngoAnimMarkerRef.current && map) {
        map.removeLayer(ngoAnimMarkerRef.current);
        ngoAnimMarkerRef.current = null;
      }
    };
  }, [activeView, activeDispatchedIncident]);

  useEffect(() => {
    if (activeView !== 'shelter') return;
    const timer = setTimeout(() => {
      if (!shelterMapContainerRef.current) return;
      if (!shelterMapInstanceRef.current) {
        const map = L.map(shelterMapContainerRef.current, {
          center: managedShelter.coordinates,
          zoom: 13,
        });
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
          maxZoom: 19,
          attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
        }).addTo(map);
        shelterMapInstanceRef.current = map;
      } else {
        shelterMapInstanceRef.current.setView(managedShelter.coordinates, 13);
        shelterMapInstanceRef.current.invalidateSize();
      }
      renderMapLayers(shelterMapInstanceRef.current, 'shelter');
    }, 120);

    return () => clearTimeout(timer);
  }, [activeView, shelters, managedShelterId, simulation, isShelterMapFullscreen]);

  // Filtered requests for NGO View
  const filteredRequests = useMemo(() => {
    return citizenRequests.filter((req) => {
      if (ngoPriorityFilter !== 'all' && req.priority !== ngoPriorityFilter) return false;
      if (ngoCategoryFilter !== 'all' && req.category !== ngoCategoryFilter) return false;
      if (ngoSearchQuery) {
        const q = ngoSearchQuery.toLowerCase();
        const matchesName = req.citizenName.toLowerCase().includes(q);
        const matchesLoc = req.locationName.toLowerCase().includes(q);
        const matchesDesc = req.description.toLowerCase().includes(q);
        if (!matchesName && !matchesLoc && !matchesDesc) return false;
      }
      return true;
    });
  }, [citizenRequests, ngoPriorityFilter, ngoCategoryFilter, ngoSearchQuery]);

  // Managed shelter stats
  const managedOccupancyRatio = managedShelter.currentOccupancy / managedShelter.totalCapacity;
  const managedOccupancyPercent = Math.round(managedOccupancyRatio * 100);

  const isFoodLow = managedShelter.resources.foodPacks < managedShelter.initialResources.foodPacks * 0.2;
  const isWaterLow = managedShelter.resources.waterLiters < managedShelter.initialResources.waterLiters * 0.2;
  const isMedicalLow = managedShelter.resources.medicalKits < managedShelter.initialResources.medicalKits * 0.2;
  const isBlanketsLow = managedShelter.resources.blankets < managedShelter.initialResources.blankets * 0.2;

  // Global calculations
  const totalBedCapacity = shelters.reduce((acc, s) => acc + s.totalCapacity, 0);
  const currentOccupancy = shelters.reduce((acc, s) => acc + s.currentOccupancy, 0);
  const availableBeds = totalBedCapacity - currentOccupancy;
  const activeSOSCount = citizenRequests.filter((r) => r.status !== 'resolved').length;
  const criticalSOSCount = citizenRequests.filter((r) => r.priority === 'critical' && r.status !== 'resolved').length;

  return (
    <div className="min-h-screen bg-[#030712] text-slate-100 flex flex-col font-['Inter',sans-serif] relative selection:bg-emerald-500/30">
      {/* ============================================================== */}
      {/* 1. TOP DISASTER SIMULATION ALERT BANNER                        */}
      {/* ============================================================== */}
      <div
        className={`w-full py-2.5 px-4 transition-colors duration-300 border-b flex flex-wrap items-center justify-between gap-3 text-xs z-30 ${
          simulation.active
            ? 'bg-gradient-to-r from-red-950 via-slate-900 to-red-950 border-red-700/80 text-red-100 shadow-lg'
            : 'bg-slate-900/80 border-slate-800 text-slate-300'
        }`}
      >
        <div className="flex items-center gap-2.5 flex-wrap">
          <div className="flex items-center gap-2 font-semibold">
            {simulation.active ? (
              <span className="relative flex h-3.5 w-3.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-80"></span>
                <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-red-600"></span>
              </span>
            ) : (
              <span className="inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
            )}
            <span className="tracking-wide uppercase font-['Plus_Jakarta_Sans',sans-serif] font-bold text-xs sm:text-sm">
              {simulation.active ? 'ACTIVE DISASTER RED-ZONE SIMULATION (1.5 KM)' : 'SYSTEM STATUS: MONITORING DEHRADUN'}
            </span>
          </div>

          <span className="text-slate-500 hidden sm:inline">|</span>

          {simulation.active ? (
            <span className="text-xs text-red-200 truncate max-w-xl">
              <span className="font-bold text-red-300">Hazard:</span> {simulation.hazardName}. Shelters inside 1.5 km circle flagged <b className="text-red-400 uppercase">UNSAFE</b>.
            </span>
          ) : (
            <span className="text-xs text-slate-400">
              Normal elevation monitoring. Tap toggle to activate Dehradun Monsoon Flash Flood Simulation.
            </span>
          )}
        </div>

        {/* Live Simulation Switch Toggle */}
        <div className="flex items-center gap-3 ml-auto">
          <span className="text-[11px] font-semibold text-slate-300 hidden md:inline">
            Simulate Active Disaster Zone
          </span>
          <button
            type="button"
            onClick={handleToggleSimulation}
            className={`relative inline-flex h-6 w-12 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-red-500/50 ${
              simulation.active ? 'bg-red-600 shadow-md shadow-red-700/50' : 'bg-slate-700'
            }`}
            aria-pressed={simulation.active}
            title="Toggle Live Disaster Zone Simulation"
          >
            <span
              className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out ${
                simulation.active ? 'translate-x-6' : 'translate-x-0'
              }`}
            />
          </button>
        </div>
      </div>

      {/* ============================================================== */}
      {/* 2. NAVBAR & HEADER                                             */}
      {/* ============================================================== */}
      <header className="sticky top-0 z-40 bg-[#070d1d]/90 backdrop-blur-md border-b border-slate-800 px-4 lg:px-8 py-3 transition-all">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
          <div
            onClick={() => switchView('home')}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="relative flex items-center justify-center">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500/20 via-cyan-500/20 to-blue-600/30 border border-emerald-500/40 flex items-center justify-center text-emerald-400 shadow-lg shadow-emerald-500/10 group-hover:border-emerald-400 group-hover:scale-105 transition-all">
                <ShieldAlert className="w-6 h-6 text-emerald-400 group-hover:text-emerald-300 transition-colors" />
              </div>
              <span className="absolute -bottom-1 -right-1 w-3 h-3 rounded-full bg-emerald-500 border-2 border-[#070d1d]"></span>
            </div>

            <div>
              <div className="flex items-center gap-2">
                <span className="font-['Plus_Jakarta_Sans',sans-serif] text-xl font-extrabold tracking-tight text-white flex items-center">
                  GARUDA<span className="text-emerald-400">RESQ</span>
                </span>
                <span className="text-[10px] font-mono font-bold tracking-widest px-1.5 py-0.5 rounded bg-emerald-950/80 text-emerald-400 border border-emerald-500/30 uppercase">
                  DEHRADUN
                </span>
              </div>
              <p className="text-[11px] text-slate-400 font-medium tracking-tight">
                Tactical Emergency Response &amp; Citizen Relief Network
              </p>
            </div>
          </div>

          {/* Primary View Switching Navigation Links */}
          <nav className="hidden md:flex items-center gap-1.5 bg-slate-900/70 p-1.5 rounded-xl border border-slate-800">
            <button
              onClick={() => switchView('home')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                activeView === 'home'
                  ? 'bg-slate-800 text-white border border-slate-700/80 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
              }`}
            >
              <Home className="w-3.5 h-3.5 text-emerald-400" />
              <span>Home</span>
            </button>

            <button
              onClick={() => switchView('citizen')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                activeView === 'citizen'
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span>Citizen Portal</span>
            </button>

            <button
              onClick={() => handleSelectRole('ngo')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                activeView === 'ngo'
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm'
                  : 'text-slate-400 hover:text-amber-300 hover:bg-slate-800/40'
              }`}
            >
              <HeartHandshake className="w-3.5 h-3.5 text-amber-400" />
              <span>NGO Command</span>
              {activeSOSCount > 0 && (
                <span className="w-4 h-4 rounded-full bg-red-600 text-white text-[9px] flex items-center justify-center font-bold">
                  {activeSOSCount}
                </span>
              )}
            </button>

            <button
              onClick={() => handleSelectRole('shelter')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                activeView === 'shelter'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                  : 'text-slate-400 hover:text-cyan-300 hover:bg-slate-800/40'
              }`}
            >
              <Building2 className="w-3.5 h-3.5 text-cyan-400" />
              <span>Shelter Hub</span>
            </button>

            <button
              onClick={() => switchView('contacts')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                activeView === 'contacts'
                  ? 'bg-slate-800 text-white border border-slate-700/60 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
              }`}
            >
              <PhoneCall className="w-3.5 h-3.5 text-amber-400" />
              <span>Helplines</span>
            </button>
          </nav>

          {/* Right Action: Active Mode Badge & Login */}
          <div className="flex items-center gap-2.5">
            <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-900/90 border border-slate-800">
              <span className="text-[11px] text-slate-400">Role:</span>
              <span className="flex items-center gap-1.5 text-xs font-semibold">
                {currentRole === 'citizen' && (
                  <span className="text-emerald-400 flex items-center gap-1">
                    <Users className="w-3.5 h-3.5" /> Citizen
                  </span>
                )}
                {currentRole === 'ngo' && (
                  <span className="text-amber-400 flex items-center gap-1">
                    <HeartHandshake className="w-3.5 h-3.5" /> NGO Commander
                  </span>
                )}
                {currentRole === 'shelter' && (
                  <span className="text-cyan-400 flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5" /> Shelter Incharge
                  </span>
                )}
              </span>
            </div>

            {authenticatedUser ? (
              <button
                onClick={handleLogout}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-red-950/70 hover:bg-red-900/70 border border-red-800/70 text-red-300 text-xs font-medium transition-all cursor-pointer"
                title="Log out back to Home mode"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Logout</span>
              </button>
            ) : (
              <button
                onClick={() => {
                  setTargetAuthRole('ngo');
                  setAuthUsername('ngo_admin');
                  setAuthPassword('resq123');
                  setAuthError('');
                  setIsAuthModalOpen(true);
                }}
                className="flex items-center gap-2 px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold shadow-md shadow-emerald-700/20 border border-emerald-400/30 transition-all cursor-pointer"
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>Role Switch / Login</span>
              </button>
            )}
          </div>
        </div>

        {/* Mobile Navigation Row */}
        <div className="flex md:hidden items-center justify-around mt-2.5 pt-2 border-t border-slate-800 text-xs">
          <button
            onClick={() => switchView('home')}
            className={`py-1 px-2 rounded font-medium ${activeView === 'home' ? 'text-emerald-400 font-bold' : 'text-slate-400'}`}
          >
            Home
          </button>
          <button
            onClick={() => switchView('citizen')}
            className={`py-1 px-2 rounded font-medium ${activeView === 'citizen' ? 'text-emerald-400 font-bold' : 'text-slate-400'}`}
          >
            Citizen
          </button>
          <button
            onClick={() => handleSelectRole('ngo')}
            className={`py-1 px-2 rounded font-medium flex items-center gap-1 ${
              activeView === 'ngo' ? 'text-amber-400 font-bold' : 'text-slate-400'
            }`}
          >
            NGO
            {activeSOSCount > 0 && (
              <span className="w-3.5 h-3.5 rounded-full bg-red-600 text-white text-[8px] flex items-center justify-center font-bold">
                {activeSOSCount}
              </span>
            )}
          </button>
          <button
            onClick={() => handleSelectRole('shelter')}
            className={`py-1 px-2 rounded font-medium ${activeView === 'shelter' ? 'text-cyan-400 font-bold' : 'text-slate-400'}`}
          >
            Shelter
          </button>
          <button
            onClick={() => switchView('contacts')}
            className={`py-1 px-2 rounded font-medium ${activeView === 'contacts' ? 'text-white font-bold' : 'text-slate-400'}`}
          >
            Helplines
          </button>
        </div>
      </header>

      {/* ============================================================== */}
      {/* FEATURE 4: DUAL SOS FLOATING PANEL (CALL + QUICK 1-TAP SOS)   */}
      {/* ============================================================== */}
      {activeView === 'citizen' && (
        <div className="fixed bottom-4 sm:bottom-6 left-4 sm:left-6 z-30 flex flex-col sm:flex-row items-stretch sm:items-center gap-2 bg-slate-950/95 backdrop-blur-xl p-2 rounded-2xl border-2 border-red-500/80 shadow-2xl max-w-[calc(100vw-2rem)] sm:max-w-none">
          {/* Option 1: Direct Hotline Call Link */}
          <a
            href="tel:1070"
            className="flex items-center gap-2 px-3.5 py-2 sm:px-4 sm:py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-red-300 font-bold text-xs border border-red-800/60 shadow transition-all cursor-pointer"
            title="Immediate direct phone dial to SDRF Uttarakhand"
          >
            <PhoneCall className="w-4 h-4 text-amber-400 animate-pulse" />
            <div className="flex flex-col text-left">
              <span className="leading-tight font-['Plus_Jakarta_Sans',sans-serif]">CALL HOTLINE</span>
              <span className="text-[9px] text-slate-400 font-mono">1070 SDRF / 112</span>
            </div>
          </a>

          {/* Option 2: Quick One-Tap SOS Broadcast */}
          <button
            onClick={handleInstantSOS}
            className="relative group flex items-center gap-2.5 px-4 py-2 sm:px-5 sm:py-2.5 rounded-xl bg-gradient-to-r from-red-600 to-rose-700 hover:from-red-500 hover:to-rose-600 text-white font-black text-xs uppercase tracking-wider shadow-lg shadow-red-700/60 border border-white/30 transition-all cursor-pointer"
          >
            <span className="w-2.5 h-2.5 rounded-full bg-white animate-ping"></span>
            <Siren className="w-4 h-4 text-white" />
            <div className="flex flex-col text-left">
              <span className="leading-tight font-['Plus_Jakarta_Sans',sans-serif]">QUICK 1-TAP SOS</span>
              <span className="text-[9px] text-red-200 lowercase font-medium">broadcast coordinates</span>
            </div>
          </button>
        </div>
      )}

      {/* ============================================================== */}
      {/* STICKY SHELTER DETAILS CARD                                    */}
      {/* ============================================================== */}
      {stickyShelterCard && (
        <div className="fixed bottom-24 sm:bottom-6 right-4 sm:right-6 z-40 w-[calc(100vw-2rem)] sm:w-11/12 max-w-sm bg-slate-900/95 backdrop-blur-xl border-2 border-emerald-500/70 p-4 rounded-2xl shadow-2xl animate-in slide-in-from-bottom duration-300">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
                <Building2 className="w-4 h-4" />
              </div>
              <div>
                <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400">Live Shelter Telemetry</span>
                <h4 className="text-sm font-bold text-white leading-tight">{stickyShelterCard.name}</h4>
              </div>
            </div>

            <button
              onClick={() => setStickyShelterCard(null)}
              className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="mt-3 text-xs space-y-2">
            <div className="flex items-center justify-between">
              <span
                className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                  isInsideHazardZone(stickyShelterCard.coordinates)
                    ? 'bg-red-950 text-red-300 border border-red-600 animate-pulse'
                    : 'bg-emerald-950 text-emerald-300 border border-emerald-600'
                }`}
              >
                {isInsideHazardZone(stickyShelterCard.coordinates) ? '⚠️ UNSAFE - INSIDE HAZARD ZONE' : '✓ VERIFIED SAFE CENTER'}
              </span>
              <span className="text-[10px] text-cyan-400 font-mono font-bold">
                {formatDistance(getDistanceInKm(citizenLocation[0], citizenLocation[1], stickyShelterCard.coordinates[0], stickyShelterCard.coordinates[1]))} away
              </span>
            </div>

            <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
              <div className="flex justify-between text-[11px] text-slate-300 mb-1">
                <span>Current Occupancy:</span>
                <span className="font-mono text-emerald-400 font-bold">
                  {stickyShelterCard.currentOccupancy} / {stickyShelterCard.totalCapacity} Beds
                </span>
              </div>
              <div className="w-full bg-slate-900 h-2 rounded-full overflow-hidden">
                <div
                  className="h-full bg-emerald-500 transition-all duration-300"
                  style={{
                    width: `${Math.round((stickyShelterCard.currentOccupancy / stickyShelterCard.totalCapacity) * 100)}%`,
                  }}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-1.5 text-[10px] text-slate-300">
              <div className="bg-slate-950 p-1.5 rounded border border-slate-800">🍞 Rations: <b>{stickyShelterCard.resources.foodPacks} packs</b></div>
              <div className="bg-slate-950 p-1.5 rounded border border-slate-800">💧 Water: <b>{stickyShelterCard.resources.waterLiters} Liters</b></div>
              <div className="bg-slate-950 p-1.5 rounded border border-slate-800">🩺 First Aid: <b>{stickyShelterCard.resources.medicalKits} kits</b></div>
              <div className="bg-slate-950 p-1.5 rounded border border-slate-800">⚡ Power: <b>{stickyShelterCard.resources.generatorPower ? 'Online' : 'Off'}</b></div>
            </div>

            <div className="flex items-center justify-between text-[11px] pt-1 text-slate-300">
              <span>Contact: {stickyShelterCard.contactPerson}</span>
              <a href={`tel:${stickyShelterCard.phone}`} className="text-emerald-400 font-bold hover:underline">
                {stickyShelterCard.phone}
              </a>
            </div>

            <div className="pt-2 flex gap-2">
              {!isInsideHazardZone(stickyShelterCard.coordinates) ? (
                <button
                  onClick={() => handleStartEvacuation(stickyShelterCard)}
                  className="flex-1 py-2 px-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs flex items-center justify-center gap-1.5 shadow-lg shadow-emerald-950/60 cursor-pointer tracking-wide"
                >
                  <Route className="w-4 h-4 text-slate-950" />
                  <span>Evacuate to Safe Zone</span>
                </button>
              ) : (
                <div className="flex-1 py-1.5 px-2 rounded-lg bg-red-950/80 text-red-400 text-center font-bold text-xs border border-red-800">
                  ⚠️ Inside Hazard Zone &bull; Routing Disabled
                </div>
              )}
              <button
                onClick={() => {
                  setManagedShelterId(stickyShelterCard.id);
                  handleSelectRole('shelter');
                }}
                className="py-1.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs flex items-center justify-center gap-1.5 border border-slate-700 cursor-pointer"
              >
                <Sliders className="w-3.5 h-3.5 text-cyan-400" />
                <span>Manage Hub</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* TOAST NOTIFICATION                                             */}
      {/* ============================================================== */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 animate-bounce duration-500 max-w-md">
          <div
            className={`px-4 py-3 rounded-xl shadow-2xl flex items-center gap-3 border backdrop-blur-md ${
              toastMessage.type === 'alert'
                ? 'bg-red-950/95 text-red-100 border-red-500/50 shadow-red-950/60'
                : toastMessage.type === 'success'
                ? 'bg-emerald-950/95 text-emerald-100 border-emerald-500/50 shadow-emerald-950/60'
                : 'bg-slate-900/95 text-slate-100 border-slate-700 shadow-black/60'
            }`}
          >
            {toastMessage.type === 'alert' && <AlertTriangle className="w-5 h-5 text-red-400 shrink-0" />}
            {toastMessage.type === 'success' && <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />}
            {toastMessage.type === 'info' && <Info className="w-5 h-5 text-cyan-400 shrink-0" />}
            <span className="text-xs font-medium">{toastMessage.text}</span>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* MAIN VIEWPORT: STRICT ISOLATED VIEW CONTAINERS                 */}
      {/* ============================================================== */}
      <main className="flex-1 flex flex-col">
        {/* ============================================================ */}
        {/* VIEW 1: DEDICATED HOME / LANDING VIEW (#view-home)            */}
        {/* ============================================================ */}
        <div id="view-home" className={activeView === 'home' ? 'flex-1 max-w-7xl mx-auto w-full px-4 lg:px-8 py-8 flex flex-col gap-10 animate-in fade-in duration-200' : 'hidden'}>
            {/* HERO SECTION */}
            <div className="relative overflow-hidden rounded-3xl bg-gradient-to-b from-slate-900 via-[#0a1122] to-[#030712] border border-slate-800 p-8 md:p-12 shadow-2xl">
              <div className="absolute top-0 right-0 -mt-16 -mr-16 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
              <div className="absolute bottom-0 left-1/4 -mb-16 w-80 h-80 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

              <div className="relative z-10 max-w-4xl">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-500/30 text-emerald-400 text-xs font-semibold mb-5">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>GarudaResQ • Dehradun Crisis Response System v3.1</span>
                </div>

                <h1 className="font-['Plus_Jakarta_Sans',sans-serif] text-3xl sm:text-5xl lg:text-6xl font-extrabold text-white tracking-tight leading-[1.15]">
                  GarudaResQ &mdash; Dehradun Emergency Response &amp; Relief Network
                </h1>

                <p className="mt-5 text-slate-300 text-sm sm:text-base lg:text-lg leading-relaxed max-w-3xl">
                  Purpose-built for the Shivalik foothill terrain, flash-flood river corridors (Rispana &amp; Bindal basins), and urban cloudburst vulnerabilities of Dehradun. Connects vulnerable citizens, tactical NGO swift-water rescue teams, and designated safe district evacuation shelters in real time.
                </p>

                {/* Primary Call-to-Action Buttons */}
                <div className="mt-8 flex flex-wrap items-center gap-3.5">
                  <button
                    onClick={() => switchView('citizen')}
                    className="flex items-center gap-2.5 px-6 py-3.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-sm tracking-wide shadow-xl shadow-emerald-500/25 transition-all cursor-pointer transform hover:-translate-y-0.5"
                  >
                    <Users className="w-4 h-4" />
                    <span>Launch Citizen Emergency Portal</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => handleSelectRole('ngo')}
                    className="flex items-center gap-2 px-5 py-3.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold text-sm tracking-wide shadow-lg shadow-amber-600/30 transition-all cursor-pointer"
                  >
                    <HeartHandshake className="w-4 h-4" />
                    <span>NGO Tactical Incident Command</span>
                  </button>

                  <button
                    onClick={() => handleSelectRole('shelter')}
                    className="flex items-center gap-2 px-5 py-3.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-slate-700 font-semibold text-sm transition-all cursor-pointer"
                  >
                    <Building2 className="w-4 h-4 text-cyan-400" />
                    <span>Manage Evacuation Shelters</span>
                  </button>

                  <button
                    onClick={() => switchView('contacts')}
                    className="flex items-center gap-2 px-4 py-3.5 rounded-xl bg-slate-900/90 hover:bg-slate-800 text-slate-300 border border-slate-800 text-sm transition-all cursor-pointer"
                  >
                    <PhoneCall className="w-4 h-4 text-amber-400" />
                    <span>24/7 Helplines (SDRF/DDMA)</span>
                  </button>
                </div>
              </div>

              {/* LIVE EMERGENCY ALERT TICKER BAR */}
              <div className="relative z-10 mt-10 pt-6 border-t border-slate-800/80 grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div className="bg-slate-950/70 p-4 rounded-2xl border border-slate-800">
                  <div className="text-[11px] text-slate-400 font-medium">Safe Shelters Online</div>
                  <div className="text-2xl font-extrabold text-emerald-400 font-mono mt-1">
                    {shelters.filter((s) => !isInsideHazardZone(s.coordinates)).length} / {shelters.length}
                  </div>
                  <div className="text-[10px] text-slate-400 mt-1">
                    {simulation.active ? '2 marked inside Hazard Zone' : 'All 5 centers operational'}
                  </div>
                </div>

                <div className="bg-slate-950/70 p-4 rounded-2xl border border-slate-800">
                  <div className="text-[11px] text-slate-400 font-medium">Total Valley Safe Beds</div>
                  <div className="text-2xl font-extrabold text-cyan-400 font-mono mt-1">
                    {availableBeds} <span className="text-xs text-slate-400 font-sans">/ {totalBedCapacity}</span>
                  </div>
                  <div className="text-[10px] text-slate-400 mt-1">Live Occupancy Synced</div>
                </div>

                <div className="bg-slate-950/70 p-4 rounded-2xl border border-slate-800">
                  <div className="text-[11px] text-slate-400 font-medium">Active Distress Beacons</div>
                  <div className="text-2xl font-extrabold text-red-400 font-mono mt-1 flex items-center gap-2">
                    {activeSOSCount}
                    {criticalSOSCount > 0 && (
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-red-950 text-red-300 border border-red-700 font-sans">
                        {criticalSOSCount} Critical
                      </span>
                    )}
                  </div>
                  <div className="text-[10px] text-slate-400 mt-1">Dehradun sectors monitored</div>
                </div>

                <div className="bg-slate-950/70 p-4 rounded-2xl border border-slate-800">
                  <div className="text-[11px] text-slate-400 font-medium">River Threat Status</div>
                  <div className="text-2xl font-extrabold text-amber-400 font-mono mt-1">
                    {simulation.active ? 'RED ALERT' : 'STABLE'}
                  </div>
                  <div className="text-[10px] text-amber-300/80 mt-1">
                    {simulation.active ? '1.5 km Hazard Active' : 'Rispana & Bindal Normal'}
                  </div>
                </div>
              </div>
            </div>

            {/* 3 DISTINCT ROLE ACCESS CARDS */}
            <div>
              <div className="mb-6">
                <h2 className="text-xl sm:text-2xl font-bold font-['Plus_Jakarta_Sans',sans-serif] text-white">
                  Mission Portals: Select Your Operating Mode
                </h2>
                <p className="text-xs sm:text-sm text-slate-400 mt-1">
                  Each role provides a completely isolated, purpose-built dashboard with specialized toolsets and dedicated tactical maps.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* ROLE CARD 1: CITIZEN PORTAL */}
                <div className="group relative bg-[#0b1329]/90 backdrop-blur-md rounded-3xl p-7 border-2 border-emerald-500/40 hover:border-emerald-400 transition-all duration-300 shadow-xl flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between mb-4">
                      <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 shadow-lg shadow-emerald-500/20">
                        <Users className="w-6 h-6" />
                      </div>
                      <span className="px-2.5 py-1 rounded-full text-[10px] font-bold tracking-wider uppercase bg-emerald-950/90 text-emerald-300 border border-emerald-600/50">
                        Direct Access &bull; No Login
                      </span>
                    </div>

                    <h3 className="font-['Plus_Jakarta_Sans',sans-serif] text-xl font-bold text-white group-hover:text-emerald-300 transition-colors">
                      Citizen Emergency Portal
                    </h3>
                    <p className="text-xs text-slate-300 mt-2.5 leading-relaxed">
                      Instant emergency navigation for individuals and families in the Dehradun valley. Access the tactical citizen map with Google Maps-style location dot, real road navigation routing lines, and Dual SOS dispatch.
                    </p>

                    <div className="mt-5 space-y-2 text-xs text-slate-300">
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                        <span>Google Maps-style Blue Location Dot with accuracy pulse</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                        <span>Real road routing line with driving &amp; walking time</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                        <span>Dual SOS Engine (Immediate Phone Call &amp; Quick 1-Tap Beacon)</span>
                      </div>
                    </div>
                  </div>

                  <div className="mt-8 pt-5 border-t border-slate-800">
                    <button
                      onClick={() => switchView('citizen')}
                      className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs tracking-wider uppercase shadow-lg shadow-emerald-600/30 flex items-center justify-center gap-2 transition-all cursor-pointer"
                    >
                      <span>Enter Citizen Emergency Dashboard</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* ROLE CARD 2: NGO RELIEF COMMAND */}
                <div className="group relative bg-[#0f172a]/90 backdrop-blur-md rounded-3xl p-7 border border-amber-500/30 hover:border-amber-400/80 transition-all duration-300 shadow-xl flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between mb-4">
                      <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 shadow-lg shadow-amber-500/20">
                        <HeartHandshake className="w-6 h-6" />
                      </div>
                      <span className="px-2.5 py-1 rounded-full text-[10px] font-bold tracking-wider uppercase bg-amber-950/90 text-amber-300 border border-amber-600/50 flex items-center gap-1">
                        <Lock className="w-3 h-3" /> Mock Login
                      </span>
                    </div>

                    <h3 className="font-['Plus_Jakarta_Sans',sans-serif] text-xl font-bold text-white group-hover:text-amber-300 transition-colors">
                      NGO Relief Operations
                    </h3>
                    <p className="text-xs text-slate-300 mt-2.5 leading-relaxed">
                      Tactical incident triage command designed for volunteer units, swift-water rescue boaters, and field medical teams operating across Dehradun.
                    </p>

                    <div className="mt-5 space-y-2 text-xs text-slate-300">
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
                        <span>Split-screen Leaflet command map with fullscreen toggle</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
                        <span>Incident Acquisition Lock (prevents duplicate NGO deployments)</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
                        <span>Real-time urgency sorting &amp; rapid dispatch controls</span>
                      </div>
                    </div>
                  </div>

                  <div className="mt-8 pt-5 border-t border-slate-800">
                    <button
                      onClick={() => handleSelectRole('ngo')}
                      className="w-full py-3 px-4 rounded-xl bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold text-xs tracking-wider uppercase shadow-lg shadow-amber-600/30 flex items-center justify-center gap-2 transition-all cursor-pointer"
                    >
                      <span>Access NGO Tactical Command</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* ROLE CARD 3: SHELTER INCHARGE HUB */}
                <div className="group relative bg-[#0b162c]/90 backdrop-blur-md rounded-3xl p-7 border border-cyan-500/30 hover:border-cyan-400/80 transition-all duration-300 shadow-xl flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between mb-4">
                      <div className="w-12 h-12 rounded-2xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400 shadow-lg shadow-cyan-500/20">
                        <Building2 className="w-6 h-6" />
                      </div>
                      <span className="px-2.5 py-1 rounded-full text-[10px] font-bold tracking-wider uppercase bg-cyan-950/90 text-cyan-300 border border-cyan-600/50 flex items-center gap-1">
                        <Lock className="w-3 h-3" /> Mock Login
                      </span>
                    </div>

                    <h3 className="font-['Plus_Jakarta_Sans',sans-serif] text-xl font-bold text-white group-hover:text-cyan-300 transition-colors">
                      Shelter Incharge Hub
                    </h3>
                    <p className="text-xs text-slate-300 mt-2.5 leading-relaxed">
                      Logistics command for managing Dehradun's evacuation centers with live real-time bed sync across all views and incoming sector alerts.
                    </p>

                    <div className="mt-5 space-y-2 text-xs text-slate-300">
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
                        <span>Live bed vacancy steppers (+5, +10) with global sync</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
                        <span>Ration, potable water, first-aid, &amp; blanket stock controls</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
                        <span>Incoming Sector Distress Alert feed &amp; evacuee intake log</span>
                      </div>
                    </div>
                  </div>

                  <div className="mt-8 pt-5 border-t border-slate-800">
                    <button
                      onClick={() => handleSelectRole('shelter')}
                      className="w-full py-3 px-4 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold text-xs tracking-wider uppercase shadow-lg shadow-cyan-600/30 flex items-center justify-center gap-2 transition-all cursor-pointer"
                    >
                      <span>Access Shelter Management Hub</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* KEY ARCHITECTURAL PILLARS */}
            <div className="bg-gradient-to-r from-blue-950/30 via-slate-900/60 to-blue-950/30 rounded-3xl p-6 md:p-8 border border-slate-800">
              <h3 className="text-base font-bold text-white font-['Plus_Jakarta_Sans',sans-serif] mb-4 flex items-center gap-2">
                <Shield className="w-5 h-5 text-emerald-400" />
                <span>Dehradun Valley Crisis Mitigation Architecture</span>
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs text-slate-300">
                <div className="bg-slate-950/60 p-4 rounded-2xl border border-slate-800">
                  <div className="font-bold text-cyan-400 flex items-center gap-1.5 mb-1 text-sm">
                    <Mountain className="w-4 h-4" /> Shivalik Foothill Modeling
                  </div>
                  <p className="leading-relaxed text-slate-400 mt-1">
                    Incorporates elevation gradients of Rajpur, Mussoorie bypass, and Prem Nagar to forecast drainage bottlenecks along Bindal and Rispana riverbeds.
                  </p>
                </div>

                <div className="bg-slate-950/60 p-4 rounded-2xl border border-slate-800">
                  <div className="font-bold text-red-400 flex items-center gap-1.5 mb-1 text-sm">
                    <Waves className="w-4 h-4" /> 1.5 km Flash-Surge Radar
                  </div>
                  <p className="leading-relaxed text-slate-400 mt-1">
                    Dynamically flags shelters located in low-lying cloudburst drainage basins as UNSAFE and reroutes citizen evacuation corridors to high-ground zones.
                  </p>
                </div>

                <div className="bg-slate-950/60 p-4 rounded-2xl border border-slate-800">
                  <div className="font-bold text-emerald-400 flex items-center gap-1.5 mb-1 text-sm">
                    <CheckSquare className="w-4 h-4" /> Instant Cross-Role Sync
                  </div>
                  <p className="leading-relaxed text-slate-400 mt-1">
                    Bed updates made by Shelter Incharges or SOS requests filed by citizens instantly update across all active Leaflet maps without page refreshes.
                  </p>
                </div>
              </div>
            </div>
        </div>

        {/* ============================================================ */}
        {/* VIEW 2: CITIZEN VIEW CONTAINER (#view-citizen)                */}
        {/* ============================================================ */}
        <div id="view-citizen" className={activeView === 'citizen' ? 'flex-1 flex flex-col w-full animate-in fade-in duration-200' : 'hidden'}>
            {/* Top Toolbar */}
            <div className="bg-slate-900/95 backdrop-blur-md border-b border-slate-800 px-4 py-2.5 z-20 flex flex-wrap items-center justify-between gap-3 shadow-md">
              <div className="flex items-center gap-2.5 flex-wrap">
                <button
                  type="button"
                  onClick={handleUseLiveGPS}
                  disabled={isGpsLocating}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-slate-950 text-xs font-bold shadow-md shadow-cyan-600/30 transition-all cursor-pointer"
                >
                  <LocateFixed className={`w-3.5 h-3.5 ${isGpsLocating ? 'animate-spin' : ''}`} />
                  <span>{isGpsLocating ? 'Acquiring GPS...' : 'Use My Live Location (GPS)'}</span>
                </button>

                <div className="flex items-center gap-1.5 bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-800 text-xs">
                  <MapPin className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                  <span className="text-slate-400 hidden sm:inline">Citizen Zone:</span>
                  <select
                    value={PRESET_ZONES.find((z) => z.name === locationLabel)?.id || ''}
                    onChange={(e) => handleSelectPresetZone(e.target.value)}
                    className="bg-transparent text-white font-semibold outline-none cursor-pointer text-xs"
                  >
                    <option value="" disabled className="bg-slate-900 text-slate-400">
                      Select Preset Dehradun Zone...
                    </option>
                    {PRESET_ZONES.map((zone) => (
                      <option key={zone.id} value={zone.id} className="bg-slate-900 text-slate-200">
                        {zone.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsDualSosModalOpen(true)}
                  className="flex items-center gap-2 px-3.5 py-1.5 rounded-lg bg-red-600 hover:bg-red-500 text-white text-xs font-black tracking-wide shadow-lg shadow-red-700/40 animate-pulse transition-all cursor-pointer"
                >
                  <Siren className="w-3.5 h-3.5 text-white" />
                  <span>EMERGENCY SOS</span>
                </button>

                <button
                  onClick={() => setIsReportModalOpen(true)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-red-950 hover:bg-red-900 border border-red-700 text-red-200 text-xs font-bold transition-all shadow-sm cursor-pointer"
                >
                  <AlertOctagon className="w-3.5 h-3.5 text-red-400" />
                  <span>Report Detailed Emergency</span>
                </button>
              </div>
            </div>

            {/* Interactive Leaflet Map for Citizen with FULLSCREEN TOGGLE & FLOATING ROUTE BANNER */}
            <div
              className={`relative w-full transition-all duration-300 ${
                isCitizenMapFullscreen
                  ? 'fixed inset-0 z-50 w-screen h-screen bg-[#030712] flex flex-col'
                  : 'h-[60vh] min-h-[400px]'
              }`}
            >
              {/* FEATURE 1: FULLSCREEN MAP TOGGLE BUTTON */}
              <button
                onClick={() => toggleMapFullscreen('citizen')}
                className="absolute top-4 right-4 z-30 p-2.5 rounded-xl bg-slate-900/95 hover:bg-slate-800 text-white border border-slate-700 shadow-2xl flex items-center gap-1.5 text-xs font-semibold backdrop-blur-md cursor-pointer transition-transform active:scale-95"
                title={isCitizenMapFullscreen ? 'Exit Fullscreen' : 'Enter Fullscreen Map'}
              >
                {isCitizenMapFullscreen ? (
                  <>
                    <Minimize2 className="w-4 h-4 text-cyan-400" />
                    <span className="hidden sm:inline">Exit Fullscreen</span>
                  </>
                ) : (
                  <>
                    <Maximize2 className="w-4 h-4 text-cyan-400" />
                    <span className="hidden sm:inline">Fullscreen Map</span>
                  </>
                )}
              </button>

              {/* FEATURE 4: REALTIME GOOGLE MAPS-STYLE FLOATING TACTICAL NAVIGATION BANNER */}
              {activeRouteShelter && !isInsideHazardZone(activeRouteShelter.coordinates) && (
                <div className="absolute top-4 left-1/2 transform -translate-x-1/2 z-30 w-11/12 max-w-2xl bg-slate-950/95 backdrop-blur-xl px-4 py-3 rounded-2xl border-2 border-blue-500 shadow-2xl flex flex-wrap sm:flex-nowrap items-center justify-between gap-3 text-xs animate-in slide-in-from-top duration-200">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-blue-500/20 border-2 border-blue-500/50 flex items-center justify-center text-blue-400 shrink-0 shadow-lg shadow-blue-500/20">
                      <Navigation className="w-5 h-5 animate-pulse text-blue-400" />
                    </div>

                    <div className="flex flex-col">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-[10px] font-mono uppercase tracking-wider text-blue-400 font-extrabold flex items-center gap-1.5 bg-blue-950/90 px-2 py-0.5 rounded border border-blue-700">
                          <span className="w-2 h-2 rounded-full bg-blue-400 animate-ping"></span>
                          NAVIGATING TO {activeRouteShelter.name.toUpperCase()}
                        </span>
                      </div>

                      <div className="flex items-center gap-3 text-slate-300 mt-1 flex-wrap text-xs font-mono">
                        <span className="text-blue-300 font-bold">
                          REMAINING DISTANCE: <span className="text-white font-extrabold">{formatDistance(navRemainingDistanceKm)}</span>
                        </span>
                        <span className="text-slate-600 hidden sm:inline">&bull;</span>
                        <span className="text-emerald-400 font-bold">
                          SPEED: SIMULATED 30 KM/H
                        </span>
                        <span className="text-slate-600 hidden md:inline">&bull;</span>
                        <span className="text-slate-400 text-[11px] hidden md:inline">
                          ~{driveTimeMins} min drive
                        </span>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={handleStopNavigation}
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-red-600 to-rose-700 hover:from-red-500 hover:to-rose-600 text-white font-black text-xs transition-all shadow-lg shadow-red-700/50 cursor-pointer shrink-0 ml-auto border border-red-400/40"
                    title="Stop Navigation"
                  >
                    <X className="w-4 h-4 text-white" />
                    <span>STOP NAVIGATION</span>
                  </button>
                </div>
              )}

              {/* Leaflet Map Canvas */}
              <div id="citizen-map" ref={citizenMapContainerRef} className="w-full h-full z-10" />

              {/* Map Legend Overlay */}
              <div className="absolute top-4 left-4 z-20 max-w-xs bg-slate-950/90 backdrop-blur-md p-3 rounded-xl border border-slate-800 shadow-xl pointer-events-auto">
                <div className="text-xs font-bold text-white mb-1.5 flex items-center justify-between">
                  <div className="flex items-center gap-1">
                    <Layers className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Citizen Tactical Map</span>
                  </div>
                  <span className="text-[10px] text-slate-400">Tap shelter for info card</span>
                </div>
                <div className="space-y-1 text-[10px] text-slate-300">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-blue-500 border border-white"></div>
                    <span>Google Maps Location Dot (You)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded bg-emerald-500"></div>
                    <span>Safe Operational Shelter</span>
                  </div>
                  {simulation.active && (
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded bg-red-600"></div>
                      <span className="text-red-400 font-bold">Unsafe (Inside 1.5 km Hazard Zone)</span>
                    </div>
                  )}
                  <div className="flex items-center gap-2">
                    <div className="w-5 h-1.5 bg-blue-500 rounded"></div>
                    <span className="text-blue-400 font-semibold">Google Maps Blue Navigation Route</span>
                  </div>
                </div>
              </div>

              {/* Floating Quick 1-Tap SOS Beacon Button on Map */}
              <button
                type="button"
                onClick={() => setIsDualSosModalOpen(true)}
                className="absolute bottom-6 right-6 z-30 flex items-center gap-2.5 px-4 py-3 rounded-2xl bg-gradient-to-r from-red-600 to-rose-700 hover:from-red-500 hover:to-rose-600 text-white font-black text-xs shadow-2xl shadow-red-950/80 border-2 border-red-400/80 backdrop-blur-md cursor-pointer transition-transform hover:scale-105 active:scale-95 group tracking-wider"
              >
                <div className="relative flex h-3 w-3">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-90"></span>
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-white"></span>
                </div>
                <Siren className="w-4 h-4 text-white group-hover:rotate-12 transition-transform" />
                <span>QUICK SOS / RESCUE</span>
              </button>
            </div>

            {/* Citizen Shelters & Quick Access List */}
            <div className="p-4 lg:p-6 max-w-7xl mx-auto w-full">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-bold text-white font-['Plus_Jakarta_Sans',sans-serif] flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-emerald-400" />
                  <span>Dehradun Safe Shelters &amp; Real-Time Capacity</span>
                </h3>
                <span className="text-xs font-mono text-cyan-400">
                  {availableBeds} total safe beds available in valley
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {shelters.map((shelter) => {
                  const inHazard = isInsideHazardZone(shelter.coordinates);
                  const dist = getDistanceInKm(citizenLocation[0], citizenLocation[1], shelter.coordinates[0], shelter.coordinates[1]);
                  const formattedDist = formatDistance(dist);
                  const isNearest = nearestSafeShelter?.id === shelter.id;
                  const isCurrentTarget = activeRouteShelter?.id === shelter.id;

                  return (
                    <div
                      key={shelter.id}
                      className={`p-4 rounded-xl border transition-all ${
                        inHazard
                          ? 'bg-red-950/20 border-red-700/60'
                          : isCurrentTarget
                          ? 'bg-emerald-950/40 border-2 border-emerald-400 shadow-xl shadow-emerald-950/50'
                          : isNearest
                          ? 'bg-emerald-950/30 border-emerald-500 shadow-lg shadow-emerald-950/40'
                          : 'bg-slate-900/60 border-slate-800'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-1 mb-2">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            inHazard
                              ? 'bg-red-950 text-red-300 border border-red-700 animate-pulse'
                              : 'bg-emerald-950 text-emerald-300 border border-emerald-700'
                          }`}
                        >
                          {inHazard ? 'UNSAFE - HAZARD ZONE' : 'OPERATIONAL SAFE'}
                        </span>
                        <span className="text-xs font-mono font-bold text-cyan-400">{formattedDist}</span>
                      </div>

                      <h4 className="text-sm font-bold text-white flex items-center justify-between">
                        <span>{shelter.name}</span>
                        {isNearest && (
                          <span className="text-[10px] px-1.5 py-0.2 rounded bg-emerald-500 text-slate-950 font-bold uppercase">
                            Nearest Safe
                          </span>
                        )}
                      </h4>
                      <p className="text-[11px] text-slate-400 mt-0.5">{shelter.locationArea}</p>

                      <div className="mt-3 flex items-center justify-between text-xs text-slate-300">
                        <span>Vacancy:</span>
                        <span className="font-mono text-emerald-400 font-bold">
                          {shelter.totalCapacity - shelter.currentOccupancy} Beds Available
                        </span>
                      </div>

                      <div className="mt-3 pt-2.5 border-t border-slate-800 flex items-center justify-between gap-2">
                        <button
                          onClick={() => setStickyShelterCard(shelter)}
                          className="text-xs text-slate-400 hover:text-white flex items-center gap-1 font-medium cursor-pointer"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>Inspect</span>
                        </button>

                        {inHazard ? (
                          <span className="text-[11px] text-red-400 font-medium">Route Disabled</span>
                        ) : (
                          <button
                            onClick={() => handleStartEvacuation(shelter)}
                            className={`px-3 py-1.5 rounded-lg font-black text-xs flex items-center gap-1.5 shadow-sm cursor-pointer transition-all ${
                              isCurrentTarget
                                ? 'bg-emerald-400 text-slate-950 ring-2 ring-emerald-300'
                                : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-700/30'
                            }`}
                          >
                            <Route className="w-3.5 h-3.5" />
                            <span>{isCurrentTarget ? 'En Route (Active)' : 'Evacuate to Safe Zone'}</span>
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
        </div>

        {/* ============================================================ */}
        {/* VIEW 3: NGO COMMAND DASHBOARD VIEW (#view-ngo)               */}
        {/* ============================================================ */}
        <div id="view-ngo" className={activeView === 'ngo' ? 'flex-1 flex flex-col w-full animate-in fade-in duration-200' : 'hidden'}>
            {/* Command Header */}
            <div className="bg-slate-900/90 border-b border-slate-800 px-4 py-2.5 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
                  <HeartHandshake className="w-4 h-4" />
                </div>
                <div>
                  <h2 className="text-sm font-bold font-['Plus_Jakarta_Sans',sans-serif] text-white">
                    NGO Tactical Incident Command &amp; Triage Center
                  </h2>
                  <p className="text-[10px] text-slate-400">Dehradun Valley Emergency Response Dispatch</p>
                </div>
              </div>

              {/* Triage Stats Ticker */}
              <div className="flex items-center gap-2 text-xs">
                <span className="px-2.5 py-1 rounded-lg bg-red-950 text-red-300 border border-red-700 font-bold font-mono">
                  {citizenRequests.filter((r) => r.status === 'pending').length} Pending
                </span>
                <span className="px-2.5 py-1 rounded-lg bg-amber-950 text-amber-300 border border-amber-700 font-bold font-mono">
                  {citizenRequests.filter((r) => r.status === 'acquired').length} Acquired
                </span>
                <span className="px-2.5 py-1 rounded-lg bg-emerald-950 text-emerald-300 border border-emerald-700 font-bold font-mono">
                  {citizenRequests.filter((r) => r.status === 'resolved').length} Resolved
                </span>
              </div>
            </div>

            {/* Split-Screen Desktop Design: Left Map | Right Triage Queue */}
            <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 min-h-[calc(100vh-160px)]">
              {/* Left Column: Dedicated Interactive Command Map (7 cols) with FULLSCREEN TOGGLE */}
              <div
                className={`lg:col-span-7 relative border-r border-slate-800 transition-all duration-300 ${
                  isNgoMapFullscreen
                    ? 'fixed inset-0 z-50 w-screen h-screen bg-[#030712] flex flex-col'
                    : 'h-[50vh] lg:h-auto'
                }`}
              >
                {/* Fullscreen Map Toggle Button */}
                <button
                  onClick={() => toggleMapFullscreen('ngo')}
                  className="absolute top-4 right-4 z-30 p-2.5 rounded-xl bg-slate-900/95 hover:bg-slate-800 text-white border border-slate-700 shadow-2xl flex items-center gap-1.5 text-xs font-semibold backdrop-blur-md cursor-pointer transition-transform active:scale-95"
                  title={isNgoMapFullscreen ? 'Exit Fullscreen' : 'Enter Fullscreen Map'}
                >
                  {isNgoMapFullscreen ? (
                    <>
                      <Minimize2 className="w-4 h-4 text-amber-400" />
                      <span className="hidden sm:inline">Exit Fullscreen</span>
                    </>
                  ) : (
                    <>
                      <Maximize2 className="w-4 h-4 text-amber-400" />
                      <span className="hidden sm:inline">Fullscreen Map</span>
                    </>
                  )}
                </button>

                {/* FEATURE 2: TACTICAL RESPONSE HEADER: EN ROUTE TO INCIDENT */}
                {activeDispatchedIncident && (
                  <div className="absolute top-4 left-1/2 transform -translate-x-1/2 z-30 w-11/12 max-w-xl bg-slate-950/95 backdrop-blur-xl px-4 py-3 rounded-2xl border-2 border-amber-500 shadow-2xl flex items-center justify-between gap-3 text-xs animate-in slide-in-from-top duration-200">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-amber-500/20 border-2 border-amber-500/50 flex items-center justify-center text-amber-400 shrink-0 shadow-lg shadow-amber-500/20">
                        <Truck className="w-5 h-5 animate-bounce" />
                      </div>

                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-[10px] font-mono uppercase tracking-wider text-amber-400 font-extrabold flex items-center gap-1.5 bg-amber-950/80 px-2 py-0.5 rounded border border-amber-700">
                            <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping"></span> STATUS: EN ROUTE TO INCIDENT {activeDispatchedIncident.id}
                          </span>
                        </div>

                        <div className="flex items-center gap-2.5 text-slate-300 mt-1 flex-wrap font-mono text-[11px]">
                          <span className="text-amber-400 font-bold">
                            DISTANCE: {formatDistance(getDistanceInKm(NGO_COMMAND_BASE[0], NGO_COMMAND_BASE[1], activeDispatchedIncident.coordinates[0], activeDispatchedIncident.coordinates[1]))}
                          </span>
                          <span className="text-slate-500">|</span>
                          <span className="text-emerald-400 font-bold">
                            EST. ARRIVAL: {Math.max(2, Math.round((getDistanceInKm(NGO_COMMAND_BASE[0], NGO_COMMAND_BASE[1], activeDispatchedIncident.coordinates[0], activeDispatchedIncident.coordinates[1]) / 35) * 60))} MINS
                          </span>
                          <span className="text-slate-500 hidden sm:inline">|</span>
                          <span className="text-slate-400 hidden sm:inline truncate max-w-[140px]">
                            {activeDispatchedIncident.locationName}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        onClick={() => handleResolveIncident(activeDispatchedIncident.id)}
                        className="px-2.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] shadow flex items-center gap-1 cursor-pointer"
                        title="Mark incident resolved and safe"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span className="hidden sm:inline">Mark Safe</span>
                      </button>

                      <button
                        onClick={() => setActiveDispatchedIncident(null)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
                        title="Cancel Dispatch Route"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                )}

                <div id="ngo-map" ref={ngoMapContainerRef} className="w-full h-full z-10" />

                <div className="absolute top-4 left-4 z-20 bg-slate-950/90 backdrop-blur-md p-3 rounded-xl border border-slate-800 shadow-xl text-[10px] space-y-1 text-slate-300">
                  <div className="font-bold text-white text-xs mb-1">Command Map Pins</div>
                  <div className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-400 border border-white"></span>
                    <span className="text-amber-300 font-bold">NGO Tactical Base (Police Lines)</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-red-600"></span>
                    <span>Pending Victim Beacon (Unassigned)</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
                    <span className="text-emerald-300 font-bold">Team Dispatched / En Route</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
                    <span className="text-amber-300 font-bold">Acquired Incident</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-slate-600"></span>
                    <span>Resolved &amp; Safe</span>
                  </div>
                </div>
              </div>

              {/* Right Column: Distress Request Triage Queue (5 cols) */}
              <div className="lg:col-span-5 bg-[#070d1d] flex flex-col h-[50vh] lg:h-auto overflow-hidden">
                {/* Filter and Search Bar */}
                <div className="p-3.5 border-b border-slate-800 bg-slate-900/60 flex flex-col gap-2">
                  <div className="flex items-center gap-2">
                    <div className="relative flex-1">
                      <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
                      <input
                        type="text"
                        value={ngoSearchQuery}
                        onChange={(e) => setNgoSearchQuery(e.target.value)}
                        placeholder="Search victims, areas, landmarks..."
                        className="w-full pl-8 pr-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-xs text-white outline-none focus:border-amber-500"
                      />
                    </div>
                  </div>

                  <div className="flex items-center gap-2 flex-wrap text-xs">
                    <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800">
                      <span className="text-[10px] text-slate-400 px-1">Urgency:</span>
                      {['all', 'critical', 'high', 'moderate'].map((u) => (
                        <button
                          key={u}
                          onClick={() => setNgoPriorityFilter(u)}
                          className={`px-2 py-0.5 rounded text-[10px] font-bold capitalize transition-all ${
                            ngoPriorityFilter === u
                              ? 'bg-amber-500 text-slate-950 shadow'
                              : 'text-slate-400 hover:text-white'
                          }`}
                        >
                          {u}
                        </button>
                      ))}
                    </div>

                    <select
                      value={ngoCategoryFilter}
                      onChange={(e) => setNgoCategoryFilter(e.target.value)}
                      className="bg-slate-950 border border-slate-800 text-slate-300 text-[10px] font-medium py-1 px-2 rounded-lg outline-none"
                    >
                      <option value="all">All Categories</option>
                      <option value="Flood">Flood</option>
                      <option value="Landslide">Landslide</option>
                      <option value="Medical">Medical</option>
                      <option value="Structural Damage">Structural</option>
                    </select>
                  </div>
                </div>

                {/* Queue Cards List */}
                <div className="flex-1 overflow-y-auto p-3.5 space-y-3">
                  {filteredRequests.length === 0 ? (
                    <div className="text-center py-12 text-slate-500 text-xs">
                      No distress signals matching current filters.
                    </div>
                  ) : (
                    filteredRequests.map((req) => {
                      const isAcquired = req.status === 'acquired';
                      const isDispatched = req.status === 'dispatched';
                      const isResolved = req.status === 'resolved';
                      const isSelected = selectedNgoRequestId === req.id;
                      const isCurrentDispatched = activeDispatchedIncident?.id === req.id;

                      return (
                        <div
                          key={req.id}
                          onClick={() => handleFocusRequestOnMap(req)}
                          className={`p-3.5 rounded-xl border text-xs transition-all cursor-pointer ${
                            isSelected
                              ? 'ring-2 ring-amber-400 bg-amber-950/40 border-amber-400 shadow-xl shadow-amber-950/60'
                              : isResolved
                              ? 'bg-slate-950/40 border-slate-800 opacity-60'
                              : isDispatched
                              ? 'bg-emerald-950/30 border-emerald-600/70 shadow-md shadow-emerald-950/30'
                              : isAcquired
                              ? 'bg-amber-950/30 border-amber-500 shadow-md shadow-amber-950/40'
                              : req.priority === 'critical'
                              ? 'bg-red-950/40 border-red-700/80 shadow'
                              : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                          }`}
                        >
                          <div className="flex items-center justify-between gap-1 mb-1.5">
                            <div className="flex items-center gap-2">
                              <span
                                className={`px-2 py-0.5 rounded text-[9px] font-extrabold uppercase ${
                                  req.priority === 'critical'
                                    ? 'bg-red-950 text-red-300 border border-red-600'
                                    : 'bg-amber-950 text-amber-300 border border-amber-600'
                                }`}
                              >
                                {req.priority}
                              </span>
                              <span className="text-[10px] text-slate-400 font-mono">{req.id}</span>
                              {isSelected && (
                                <span className="text-[9px] font-bold text-amber-400 px-1.5 py-0.5 rounded bg-amber-950 border border-amber-700">
                                  MAP FOCUSED
                                </span>
                              )}
                            </div>

                            <div className="flex items-center gap-1.5 text-[10px] text-slate-400">
                              <Clock className="w-3 h-3" />
                              <span>{req.timestamp}</span>
                            </div>
                          </div>

                          <div className="font-bold text-white text-sm flex items-center justify-between">
                            <span>{req.citizenName}</span>
                            <span className="text-cyan-400 text-xs font-mono font-medium">
                              👥 {req.peopleCount} Affected
                            </span>
                          </div>

                          <div className="text-[11px] text-cyan-300 mt-0.5 flex items-center gap-1">
                            <MapPin className="w-3 h-3 text-cyan-400 shrink-0" />
                            <span>{req.locationName}</span>
                          </div>

                          <p className="text-slate-300 text-[11px] bg-slate-950 p-2 rounded-lg border border-slate-800 mt-2">
                            "{req.description}"
                          </p>

                          {/* TEAM DISPATCHED ACTIVE STATUS BADGE */}
                          {isDispatched && (
                            <div className="mt-2.5 px-2.5 py-1.5 rounded-lg bg-emerald-950/90 text-emerald-300 border border-emerald-600/80 text-[10px] font-black flex items-center justify-between shadow-sm">
                              <div className="flex items-center gap-1.5">
                                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
                                <Truck className="w-3.5 h-3.5 text-emerald-400" />
                                <span>TEAM DISPATCHED &bull; EN ROUTE</span>
                              </div>
                              <span className="text-[9px] font-mono text-emerald-300 font-bold">{req.acquiredBy || 'Alpha Unit'}</span>
                            </div>
                          )}

                          {isAcquired && !isDispatched && (
                            <div className="mt-2.5 px-2.5 py-1 rounded bg-amber-950/80 text-amber-300 border border-amber-600/60 text-[10px] font-extrabold flex items-center gap-1.5">
                              <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                              <span>ACQUIRED BY YOUR TEAM • RESPONDING IN PROGRESS</span>
                            </div>
                          )}

                          <div className="mt-3 pt-2.5 border-t border-slate-800 flex items-center justify-between gap-2 flex-wrap">
                            <span className="font-mono text-cyan-400 text-[10px]">
                              📞 {req.contactNumber}
                            </span>

                            <div className="flex items-center gap-1.5">
                              {!isResolved && (
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleDeployResponseTeam(req);
                                  }}
                                  className={`px-3 py-1.5 rounded-lg font-black text-xs flex items-center gap-1.5 shadow-md transition-all cursor-pointer ${
                                    isCurrentDispatched
                                      ? 'bg-amber-400 text-slate-950 ring-2 ring-white animate-pulse'
                                      : 'bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 shadow-amber-500/20'
                                  }`}
                                  title="Deploy response team and trace route from NGO Base"
                                >
                                  <Truck className="w-3.5 h-3.5" />
                                  <span>{isCurrentDispatched ? 'En Route (Active)' : 'Deploy Response Team'}</span>
                                </button>
                              )}

                              {!isResolved && (
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleResolveIncident(req.id);
                                  }}
                                  className="px-2.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1 shadow-sm cursor-pointer"
                                  title="Mark incident safe and resolved"
                                >
                                  <CheckCircle2 className="w-3.5 h-3.5" />
                                  <span>Resolve</span>
                                </button>
                              )}

                              {isResolved && (
                                <span className="text-[10px] text-emerald-400 font-bold flex items-center gap-1">
                                  <CheckCircle2 className="w-3.5 h-3.5" /> Safe &bull; Resolved
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            </div>
          </div>

        {/* ============================================================ */}
        {/* VIEW 4: SHELTER INCHARGE DASHBOARD VIEW (#view-shelter)      */}
        {/* ============================================================ */}
        <div id="view-shelter" className={activeView === 'shelter' ? 'flex-1 flex flex-col w-full animate-in fade-in duration-200 p-4 lg:p-6 max-w-7xl mx-auto' : 'hidden'}>
            {/* Header with Shelter Selector */}
            <div className="bg-slate-900/90 rounded-2xl p-4 border border-slate-800 flex flex-wrap items-center justify-between gap-4 mb-6 shadow-xl">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400">
                  <Building2 className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-base font-bold font-['Plus_Jakarta_Sans',sans-serif] text-white">
                    Shelter Incharge Operations Hub
                  </h2>
                  <p className="text-xs text-slate-400">Real-time occupancy synchronization across all views</p>
                </div>
              </div>

              <div className="flex items-center gap-2 bg-slate-950 p-1.5 rounded-xl border border-slate-800 text-xs">
                <span className="text-slate-400 px-1">Managed Facility:</span>
                <select
                  value={managedShelterId}
                  onChange={(e) => setManagedShelterId(e.target.value)}
                  className="bg-transparent text-cyan-300 font-bold outline-none cursor-pointer"
                >
                  {shelters.map((s) => (
                    <option key={s.id} value={s.id} className="bg-slate-900 text-slate-200">
                      {s.name} ({s.currentOccupancy}/{s.totalCapacity})
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Two-Column Grid: Left Controls | Right Map & Evacuee Log */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Left Column (5 cols): Dynamic Shelter Occupancy & Resource Controls */}
              <div className="lg:col-span-5 space-y-6">
                <div className="bg-slate-900/80 rounded-2xl p-5 border border-slate-800 shadow-xl">
                  <div className="flex items-center justify-between mb-3 border-b border-slate-800 pb-2.5">
                    <span className="text-xs font-bold text-white uppercase tracking-wider font-['Plus_Jakarta_Sans',sans-serif]">
                      Live Capacity Management
                    </span>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        isInsideHazardZone(managedShelter.coordinates)
                          ? 'bg-red-950 text-red-300 border border-red-700 animate-pulse'
                          : managedShelter.status === 'full'
                          ? 'bg-red-950 text-red-300'
                          : managedShelter.status === 'high_occupancy'
                          ? 'bg-amber-950 text-amber-300'
                          : 'bg-emerald-950 text-emerald-300'
                      }`}
                    >
                      {isInsideHazardZone(managedShelter.coordinates)
                        ? 'UNSAFE - INSIDE HAZARD ZONE'
                        : managedShelter.status.toUpperCase()}
                    </span>
                  </div>

                  <h3 className="text-base font-bold text-white">{managedShelter.name}</h3>
                  <p className="text-xs text-slate-400 mt-0.5">{managedShelter.locationArea}</p>

                  <div className="mt-4 bg-slate-950 p-4 rounded-xl border border-slate-800 text-center">
                    <div className="text-3xl font-extrabold font-mono text-emerald-400">
                      {managedShelter.currentOccupancy}
                      <span className="text-sm font-sans text-slate-400"> / {managedShelter.totalCapacity} Beds</span>
                    </div>
                    <div className="text-xs text-slate-400 mt-1">
                      {managedShelter.totalCapacity - managedShelter.currentOccupancy} Beds Available ({managedOccupancyPercent}% Full)
                    </div>

                    <div className="w-full bg-slate-900 h-3 rounded-full overflow-hidden mt-3">
                      <div
                        className={`h-full transition-all duration-300 ${
                          managedShelter.currentOccupancy >= managedShelter.totalCapacity
                            ? 'bg-red-500'
                            : managedOccupancyPercent >= 75
                            ? 'bg-amber-400'
                            : 'bg-emerald-500'
                        }`}
                        style={{ width: `${managedOccupancyPercent}%` }}
                      />
                    </div>
                  </div>

                  <div className="mt-4">
                    <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-2">
                      Quick Action Occupancy Adjusters:
                    </div>
                    <div className="grid grid-cols-4 gap-2">
                      <button
                        onClick={() => handleAdjustOccupancy(managedShelterId, 5)}
                        className="py-2 rounded-xl bg-emerald-950 hover:bg-emerald-900 text-emerald-300 border border-emerald-700/60 font-bold text-xs flex items-center justify-center gap-1 cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" /> 5
                      </button>
                      <button
                        onClick={() => handleAdjustOccupancy(managedShelterId, 10)}
                        className="py-2 rounded-xl bg-emerald-950 hover:bg-emerald-900 text-emerald-300 border border-emerald-700/60 font-bold text-xs flex items-center justify-center gap-1 cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" /> 10
                      </button>
                      <button
                        onClick={() => handleAdjustOccupancy(managedShelterId, -5)}
                        className="py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-bold text-xs flex items-center justify-center gap-1 cursor-pointer"
                      >
                        <Minus className="w-3.5 h-3.5" /> 5
                      </button>
                      <button
                        onClick={() => handleAdjustOccupancy(managedShelterId, -10)}
                        className="py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-bold text-xs flex items-center justify-center gap-1 cursor-pointer"
                      >
                        <Minus className="w-3.5 h-3.5" /> 10
                      </button>
                    </div>

                    <button
                      onClick={() => setIsCustomCapacityModalOpen(true)}
                      className="w-full mt-2 py-2 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 text-cyan-300 border border-slate-700 text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <Settings2 className="w-3.5 h-3.5" />
                      <span>Set Custom Capacity Value</span>
                    </button>
                  </div>
                </div>

                {/* Resource Stock Management */}
                <div className="bg-slate-900/80 rounded-2xl p-5 border border-slate-800 shadow-xl">
                  <div className="flex items-center justify-between mb-3 border-b border-slate-800 pb-2.5">
                    <span className="text-xs font-bold text-white uppercase tracking-wider font-['Plus_Jakarta_Sans',sans-serif]">
                      Resource Inventory Controls
                    </span>
                    <span className="text-[10px] text-slate-400">Alert threshold: &lt;20%</span>
                  </div>

                  <div className="space-y-3 text-xs">
                    <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                      <div className="flex items-center justify-between">
                        <span className="font-semibold text-slate-300 flex items-center gap-1.5">
                          <span>🍞 Ready Meals (Packs)</span>
                          {isFoodLow && (
                            <span className="px-1.5 py-0.2 rounded bg-red-950 text-red-300 border border-red-700 text-[9px] font-bold uppercase animate-pulse">
                              Low Stock
                            </span>
                          )}
                        </span>
                        <span className="font-mono font-bold text-emerald-400 text-sm">
                          {managedShelter.resources.foodPacks}
                        </span>
                      </div>
                      <div className="mt-2 flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => handleAdjustResource(managedShelterId, 'foodPacks', -50)}
                          className="px-2 py-1 rounded bg-slate-800 text-[10px] font-bold text-slate-300"
                        >
                          -50
                        </button>
                        <button
                          onClick={() => handleAdjustResource(managedShelterId, 'foodPacks', 100)}
                          className="px-2 py-1 rounded bg-emerald-950 text-emerald-300 border border-emerald-700 text-[10px] font-bold"
                        >
                          +100 Restock
                        </button>
                      </div>
                    </div>

                    <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                      <div className="flex items-center justify-between">
                        <span className="font-semibold text-slate-300 flex items-center gap-1.5">
                          <span>💧 Clean Potable Water (Liters)</span>
                          {isWaterLow && (
                            <span className="px-1.5 py-0.2 rounded bg-red-950 text-red-300 border border-red-700 text-[9px] font-bold uppercase animate-pulse">
                              Low Stock
                            </span>
                          )}
                        </span>
                        <span className="font-mono font-bold text-cyan-400 text-sm">
                          {managedShelter.resources.waterLiters} L
                        </span>
                      </div>
                      <div className="mt-2 flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => handleAdjustResource(managedShelterId, 'waterLiters', -200)}
                          className="px-2 py-1 rounded bg-slate-800 text-[10px] font-bold text-slate-300"
                        >
                          -200L
                        </button>
                        <button
                          onClick={() => handleAdjustResource(managedShelterId, 'waterLiters', 500)}
                          className="px-2 py-1 rounded bg-cyan-950 text-cyan-300 border border-cyan-700 text-[10px] font-bold"
                        >
                          +500L Tanker
                        </button>
                      </div>
                    </div>

                    <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                      <div className="flex items-center justify-between">
                        <span className="font-semibold text-slate-300 flex items-center gap-1.5">
                          <span>🩺 Trauma &amp; First Aid Kits</span>
                          {isMedicalLow && (
                            <span className="px-1.5 py-0.2 rounded bg-red-950 text-red-300 border border-red-700 text-[9px] font-bold uppercase animate-pulse">
                              Low Stock
                            </span>
                          )}
                        </span>
                        <span className="font-mono font-bold text-amber-400 text-sm">
                          {managedShelter.resources.medicalKits}
                        </span>
                      </div>
                      <div className="mt-2 flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => handleAdjustResource(managedShelterId, 'medicalKits', -10)}
                          className="px-2 py-1 rounded bg-slate-800 text-[10px] font-bold text-slate-300"
                        >
                          -10
                        </button>
                        <button
                          onClick={() => handleAdjustResource(managedShelterId, 'medicalKits', 25)}
                          className="px-2 py-1 rounded bg-amber-950 text-amber-300 border border-amber-700 text-[10px] font-bold"
                        >
                          +25 Kits
                        </button>
                      </div>
                    </div>

                    <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                      <div className="flex items-center justify-between">
                        <span className="font-semibold text-slate-300 flex items-center gap-1.5">
                          <span>🛏️ Thermal Blankets</span>
                          {isBlanketsLow && (
                            <span className="px-1.5 py-0.2 rounded bg-red-950 text-red-300 border border-red-700 text-[9px] font-bold uppercase animate-pulse">
                              Low Stock
                            </span>
                          )}
                        </span>
                        <span className="font-mono font-bold text-slate-200 text-sm">
                          {managedShelter.resources.blankets}
                        </span>
                      </div>
                      <div className="mt-2 flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => handleAdjustResource(managedShelterId, 'blankets', -20)}
                          className="px-2 py-1 rounded bg-slate-800 text-[10px] font-bold text-slate-300"
                        >
                          -20
                        </button>
                        <button
                          onClick={() => handleAdjustResource(managedShelterId, 'blankets', 50)}
                          className="px-2 py-1 rounded bg-slate-800 text-white border border-slate-600 text-[10px] font-bold"
                        >
                          +50 Blankets
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Right Column (7 cols): Interactive Shelter Map & Evacuee Log */}
              <div className="lg:col-span-7 space-y-6 flex flex-col">
                <div
                  className={`bg-slate-900/80 rounded-2xl p-4 border border-slate-800 shadow-xl flex flex-col transition-all duration-300 ${
                    isShelterMapFullscreen
                      ? 'fixed inset-0 z-50 w-screen h-screen bg-[#030712] flex flex-col p-4'
                      : ''
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold text-white font-['Plus_Jakarta_Sans',sans-serif]">
                      Facility Geographic Surroundings &amp; Hazard Radar
                    </span>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] text-cyan-400 font-mono">
                        {managedShelter.coordinates[0]}°N, {managedShelter.coordinates[1]}°E
                      </span>
                      <button
                        onClick={() => toggleMapFullscreen('shelter')}
                        className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs"
                        title={isShelterMapFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}
                      >
                        {isShelterMapFullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>

                  <div className={`w-full rounded-xl overflow-hidden border border-slate-800 relative ${isShelterMapFullscreen ? 'flex-1' : 'h-64'}`}>
                    <div id="shelter-map" ref={shelterMapContainerRef} className="w-full h-full z-10" />
                  </div>
                </div>

                {/* Evacuee Log Table */}
                <div className="bg-slate-900/80 rounded-2xl p-5 border border-slate-800 shadow-xl flex-1 flex flex-col">
                  <div className="flex items-center justify-between mb-3 border-b border-slate-800 pb-2.5">
                    <div>
                      <h3 className="text-sm font-bold text-white font-['Plus_Jakarta_Sans',sans-serif] flex items-center gap-2">
                        <FileSpreadsheet className="w-4 h-4 text-cyan-400" />
                        <span>Incoming Evacuee Roster &amp; Special Triage</span>
                      </h3>
                      <p className="text-[11px] text-slate-400">Registered admissions for {managedShelter.name}</p>
                    </div>

                    <button
                      onClick={() => setIsCheckInModalOpen(true)}
                      className="px-3 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-md shadow-cyan-600/30 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Check-In Evacuee</span>
                    </button>
                  </div>

                  <div className="flex-1 overflow-x-auto">
                    <table className="w-full text-left text-xs">
                      <thead>
                        <tr className="border-b border-slate-800 text-[10px] uppercase text-slate-400 font-semibold tracking-wider">
                          <th className="py-2 px-2">ID</th>
                          <th className="py-2 px-2">Family Head</th>
                          <th className="py-2 px-2">Count</th>
                          <th className="py-2 px-2">Origin Area</th>
                          <th className="py-2 px-2">Medical Needs</th>
                          <th className="py-2 px-2">Block</th>
                          <th className="py-2 px-2 text-right">Status</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800/60">
                        {evacueeLogs
                          .filter((e) => e.shelterId === managedShelterId)
                          .map((log) => (
                            <tr key={log.id} className="hover:bg-slate-800/30 transition-colors">
                              <td className="py-2.5 px-2 font-mono text-cyan-400 text-[11px] font-bold">
                                {log.id}
                              </td>
                              <td className="py-2.5 px-2 font-bold text-white">{log.headOfFamily}</td>
                              <td className="py-2.5 px-2 font-mono text-slate-300">{log.peopleCount}</td>
                              <td className="py-2.5 px-2 text-slate-300 text-[11px]">{log.originArea}</td>
                              <td className="py-2.5 px-2 text-slate-400 text-[11px] max-w-xs truncate">
                                {log.medicalNeeds}
                              </td>
                              <td className="py-2.5 px-2 font-mono text-amber-300 text-[11px]">
                                {log.allocatedBlock}
                              </td>
                              <td className="py-2.5 px-2 text-right">
                                <span className="px-2 py-0.5 rounded text-[9px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-700">
                                  {log.status}
                                </span>
                              </td>
                            </tr>
                          ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
        </div>

        {/* ============================================================ */}
        {/* VIEW 5: EMERGENCY CONTACTS VIEW (#view-contacts)             */}
        {/* ============================================================ */}
        <div id="view-contacts" className={activeView === 'contacts' ? 'flex-1 max-w-7xl mx-auto w-full px-4 lg:px-8 py-8 flex flex-col gap-6 animate-in fade-in duration-200' : 'hidden'}>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
              <div>
                <h2 className="text-2xl font-bold font-['Plus_Jakarta_Sans',sans-serif] text-white flex items-center gap-2">
                  <PhoneCall className="w-6 h-6 text-amber-400" />
                  <span>Dehradun Official Emergency Helplines &amp; Control Rooms</span>
                </h2>
                <p className="text-xs sm:text-sm text-slate-400 mt-1">
                  Verified 24/7 tactical rescue, disaster management, and medical trauma centers for Dehradun and Uttarakhand.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs px-3 py-1.5 rounded-lg bg-emerald-950/80 text-emerald-400 border border-emerald-600/40 font-mono font-bold">
                  VHF RADIO: CH-04 / CH-07
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {EMERGENCY_CONTACTS.map((contact) => (
                <div
                  key={contact.id}
                  className="bg-slate-900/80 backdrop-blur-md rounded-2xl p-6 border border-slate-800 hover:border-slate-700 transition-all shadow-xl flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold tracking-wider uppercase bg-slate-800 text-cyan-300 border border-slate-700">
                        {contact.badge}
                      </span>
                      <span className="text-xs text-slate-400">{contact.category}</span>
                    </div>

                    <h3 className="text-base font-bold text-white font-['Plus_Jakarta_Sans',sans-serif] leading-snug">
                      {contact.agency}
                    </h3>

                    <p className="text-xs text-slate-300 mt-2.5 leading-relaxed">
                      {contact.description}
                    </p>

                    <div className="mt-4 flex items-center gap-1.5 text-xs text-slate-400">
                      <MapPin className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                      <span className="truncate">{contact.location}</span>
                    </div>
                  </div>

                  <div className="mt-6 pt-4 border-t border-slate-800/80 flex items-center justify-between gap-3">
                    <div>
                      <div className="text-[10px] text-slate-400 uppercase font-mono">Emergency Direct</div>
                      <div className="text-lg font-extrabold text-emerald-400 font-mono tracking-wider">
                        {contact.phone}
                      </div>
                    </div>

                    <a
                      href={`tel:${contact.phone.replace(/[^0-9+]/g, '')}`}
                      className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md shadow-emerald-700/20 flex items-center gap-1.5 transition-all cursor-pointer"
                    >
                      <PhoneCall className="w-3.5 h-3.5" />
                      <span>Call Now</span>
                    </a>
                  </div>
                </div>
              ))}
            </div>
        </div>
      </main>

      {/* ============================================================== */}
      {/* MODAL: CUSTOM CAPACITY (SHELTER INCHARGE)                     */}
      {/* ============================================================== */}
      {isCustomCapacityModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="w-full max-w-sm bg-[#0a1122] rounded-3xl border border-slate-700 p-6 shadow-2xl">
            <h3 className="text-base font-bold text-white mb-2">Set Custom Occupancy</h3>
            <p className="text-xs text-slate-400 mb-4">
              Enter the exact bed count currently in use at <b>{managedShelter.name}</b> (Max: {managedShelter.totalCapacity}).
            </p>

            <form onSubmit={handleSetCustomOccupancy}>
              <input
                type="number"
                min="0"
                max={managedShelter.totalCapacity}
                value={customCapacityValue}
                onChange={(e) => setCustomCapacityValue(e.target.value)}
                placeholder="e.g. 450"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm font-mono outline-none focus:border-cyan-500"
                autoFocus
              />

              <div className="mt-4 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsCustomCapacityModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold text-xs shadow cursor-pointer"
                >
                  Update Capacity
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* MODAL: QUICK EVACUEE CHECK-IN (SHELTER INCHARGE)              */}
      {/* ============================================================== */}
      {isCheckInModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="w-full max-w-md bg-[#0a1122] rounded-3xl border border-slate-700 p-6 shadow-2xl">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-base font-bold text-white">Admit Evacuee Family</h3>
              <button
                onClick={() => setIsCheckInModalOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCheckInEvacueeSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Head of Family Name</label>
                <input
                  type="text"
                  required
                  value={checkInName}
                  onChange={(e) => setCheckInName(e.target.value)}
                  placeholder="e.g. Ramesh Chandra Joshi"
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white outline-none focus:border-cyan-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Total Family Members</label>
                  <input
                    type="number"
                    min="1"
                    max="20"
                    required
                    value={checkInPeopleCount}
                    onChange={(e) => setCheckInPeopleCount(parseInt(e.target.value, 10) || 1)}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white font-mono outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Origin Flooded Sector</label>
                  <input
                    type="text"
                    required
                    value={checkInOrigin}
                    onChange={(e) => setCheckInOrigin(e.target.value)}
                    placeholder="e.g. Chander Nagar Basin"
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Medical / Diet Needs</label>
                <input
                  type="text"
                  value={checkInNeeds}
                  onChange={(e) => setCheckInNeeds(e.target.value)}
                  placeholder="e.g. Diabetics meds, infant formula"
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white outline-none"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsCheckInModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold shadow cursor-pointer"
                >
                  Confirm Check-In
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* MODAL: EMERGENCY ASSISTANCE REPORTING                          */}
      {/* ============================================================== */}
      {isReportModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="relative w-full max-w-lg bg-[#0a1122] rounded-3xl border border-slate-700/80 p-6 md:p-8 shadow-2xl overflow-hidden max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-red-950/80 border border-red-700/60 flex items-center justify-center text-red-400 shadow">
                  <AlertOctagon className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-['Plus_Jakarta_Sans',sans-serif] text-lg font-bold text-white">
                    Report Detailed Emergency
                  </h3>
                  <p className="text-[11px] text-slate-400">GarudaResQ Dehradun Citizen Rescue Dispatch</p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setIsReportModalOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleReportAssistanceSubmit} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">
                    Contact Phone Number <span className="text-red-400">*</span>
                  </label>
                  <input
                    type="tel"
                    required
                    value={reportPhone}
                    onChange={(e) => setReportPhone(e.target.value)}
                    placeholder="+91 98970 XXXXX"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-cyan-500 text-white font-mono outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">
                    Exact Landmark / Street <span className="text-red-400">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={reportLandmark}
                    onChange={(e) => setReportLandmark(e.target.value)}
                    placeholder="e.g. Near Tapovan Bridge, Rajpur Rd"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-cyan-500 text-white outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1.5">Emergency Category</label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {(['Flood', 'Landslide', 'Structural Damage', 'Medical'] as const).map((cat) => (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => setReportCategory(cat)}
                      className={`py-2 px-2.5 rounded-xl font-bold text-center border transition-all ${
                        reportCategory === cat
                          ? 'bg-red-600 text-white border-red-400 shadow-md shadow-red-700/30'
                          : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Affected People</label>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setReportPeopleCount((p) => Math.max(1, p - 1))}
                      className="w-9 h-9 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-bold"
                    >
                      -
                    </button>
                    <span className="w-12 text-center font-mono font-bold text-base text-white">
                      {reportPeopleCount}
                    </span>
                    <button
                      type="button"
                      onClick={() => setReportPeopleCount((p) => p + 1)}
                      className="w-9 h-9 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-bold"
                    >
                      +
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Severity Rating</label>
                  <select
                    value={reportSeverity}
                    onChange={(e) => setReportSeverity(e.target.value as any)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white font-semibold outline-none"
                  >
                    <option value="critical">CRITICAL (Immediate Life Threat)</option>
                    <option value="high">HIGH (Rising Water / Trapped)</option>
                    <option value="moderate">MODERATE (Supplies Exhausted)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Situation Description</label>
                <textarea
                  required
                  rows={3}
                  value={reportDescription}
                  onChange={(e) => setReportDescription(e.target.value)}
                  placeholder="Detail water level, trapped family members, or urgent medical needs..."
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 focus:border-cyan-500 text-white outline-none resize-none"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsReportModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl text-slate-400 hover:text-white font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold tracking-wide shadow-lg shadow-red-700/30 flex items-center gap-2 cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                  <span>Submit Distress Signal</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* MODAL: DUAL SOS ENGINE (HOTLINE CALL + 1-TAP RESCUE BROADCAST) */}
      {/* ============================================================== */}
      {isDualSosModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
          <div className="relative w-full max-w-lg bg-[#0c0505] rounded-3xl border-2 border-red-600/80 p-6 md:p-8 shadow-2xl overflow-hidden">
            <div className="absolute -top-24 -left-24 w-48 h-48 bg-red-600/20 rounded-full blur-3xl pointer-events-none" />
            <div className="absolute -bottom-24 -right-24 w-48 h-48 bg-red-600/20 rounded-full blur-3xl pointer-events-none" />

            <div className="relative z-10 flex items-center justify-between pb-4 border-b border-red-900/60 mb-5">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-2xl bg-red-600/20 border border-red-500 flex items-center justify-center text-red-400 shadow-lg shadow-red-950/60">
                  <Siren className="w-6 h-6 animate-pulse" />
                </div>
                <div>
                  <h3 className="font-['Plus_Jakarta_Sans',sans-serif] text-xl font-black text-white tracking-tight flex items-center gap-2">
                    <span>DUAL SOS ENGINE</span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-red-950 text-red-300 border border-red-700 uppercase">
                      CRITICAL
                    </span>
                  </h3>
                  <p className="text-xs text-red-300/80">Immediate Rescue Assistance for Dehradun Region</p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setIsDualSosModalOpen(false)}
                className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800/80 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-300 mb-5 leading-relaxed">
              If you or someone nearby is in acute danger, stranded in rising waters of the Rispana/Bindal basins, or trapped by landslides, choose an emergency response action below:
            </p>

            <div className="space-y-4">
              {/* OPTION 1: QUICK 1-TAP SOS BROADCAST */}
              <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-red-950/70 via-red-900/40 to-slate-900/70 border-2 border-red-500/80 shadow-xl relative overflow-hidden group">
                <div className="flex items-start justify-between gap-3 mb-2.5">
                  <div>
                    <span className="inline-block px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase bg-red-600 text-white mb-1">
                      OPTION 1 &bull; RAPID ONE-TAP BEACON
                    </span>
                    <h4 className="text-sm sm:text-base font-extrabold text-white flex items-center gap-2">
                      <span>Quick One-Tap SOS Broadcast</span>
                    </h4>
                  </div>
                  <Radio className="w-5 h-5 text-red-400 shrink-0 animate-pulse" />
                </div>

                <p className="text-xs text-slate-300 mb-3.5 leading-relaxed">
                  Broadcasts your current GPS position (<span className="text-cyan-400 font-mono font-bold">{citizenLocation[0].toFixed(5)}°N, {citizenLocation[1].toFixed(5)}°E</span>) directly into the active NGO Tactical Queue and SDRF dispatch feed in 1 tap without filling out any forms.
                </p>

                <button
                  type="button"
                  onClick={handleInstantSOS}
                  className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white font-black text-xs uppercase tracking-wider shadow-lg shadow-red-700/50 flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-[0.98]"
                >
                  <Siren className="w-4 h-4 text-white" />
                  <span>ACTIVATE 1-TAP RESCUE BEACON NOW</span>
                </button>
              </div>

              {/* OPTION 2: CALL EMERGENCY HOTLINE */}
              <div className="p-4 sm:p-5 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-lg">
                <div className="flex items-start justify-between gap-3 mb-2">
                  <div>
                    <span className="inline-block px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase bg-amber-500/20 text-amber-300 border border-amber-500/40 mb-1">
                      OPTION 2 &bull; 24/7 HELPLINE CALL
                    </span>
                    <h4 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
                      <span>Call Emergency Response Hotline</span>
                    </h4>
                  </div>
                  <PhoneCall className="w-5 h-5 text-amber-400 shrink-0" />
                </div>

                <p className="text-xs text-slate-400 mb-3.5 leading-relaxed">
                  Direct connection to Uttarakhand State Disaster Response Force (SDRF) or District Emergency Operations Centre (DEOC).
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <a
                    href="tel:1070"
                    className="py-3 px-3 rounded-xl bg-slate-950 hover:bg-slate-800 border border-red-500/50 text-red-300 font-bold text-xs flex items-center justify-center gap-2 shadow-sm transition-all"
                  >
                    <PhoneCall className="w-3.5 h-3.5 text-red-400" />
                    <span>Dial SDRF (1070)</span>
                  </a>

                  <a
                    href="tel:112"
                    className="py-3 px-3 rounded-xl bg-slate-950 hover:bg-slate-800 border border-cyan-500/50 text-cyan-300 font-bold text-xs flex items-center justify-center gap-2 shadow-sm transition-all"
                  >
                    <PhoneCall className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Dial Police &amp; EMS (112)</span>
                  </a>
                </div>
              </div>
            </div>

            <div className="mt-5 pt-4 border-t border-slate-900 flex items-center justify-between text-xs text-slate-400">
              <button
                type="button"
                onClick={() => {
                  setIsDualSosModalOpen(false);
                  setIsReportModalOpen(true);
                }}
                className="text-slate-400 hover:text-white underline font-medium cursor-pointer"
              >
                Prefer to fill detailed damage report?
              </button>

              <button
                type="button"
                onClick={() => setIsDualSosModalOpen(false)}
                className="text-slate-500 hover:text-slate-300 font-medium cursor-pointer"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* MODAL: INSTANT SOS CONFIRMATION OVERLAY                         */}
      {/* ============================================================== */}
      {sosAlertOverlay && sosAlertOverlay.isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-red-950/90 backdrop-blur-xl animate-in fade-in duration-300">
          <div className="relative w-full max-w-lg bg-[#0c0505] rounded-3xl border-2 border-red-500 p-6 md:p-8 shadow-2xl text-center overflow-hidden">
            <div className="w-20 h-20 mx-auto rounded-full bg-red-600/20 border-2 border-red-500 flex items-center justify-center text-red-500 shadow-xl mb-4">
              <Siren className="w-10 h-10 animate-pulse text-red-400" />
            </div>

            <div className="inline-block px-3 py-1 rounded-full bg-red-950 text-red-300 border border-red-700 text-xs font-mono font-bold tracking-widest mb-2">
              DISTRESS ID: {sosAlertOverlay.trackingId}
            </div>

            <h3 className="font-['Plus_Jakarta_Sans',sans-serif] text-2xl font-black text-white tracking-tight">
              SOS ALERT TRANSMITTED TO RELIEF TEAMS
            </h3>

            <p className="text-sm font-bold text-red-400 mt-2 uppercase tracking-wide">
              STAY CALM • YOUR EMERGENCY BEACON IS ACTIVE
            </p>

            <div className="mt-4 p-4 rounded-2xl bg-red-950/40 border border-red-900/60 text-xs text-slate-300 space-y-2 text-left">
              <div className="flex justify-between border-b border-red-900/40 pb-1.5">
                <span className="text-slate-400">Transmitted Coordinates:</span>
                <span className="font-mono text-cyan-400 font-bold">
                  {sosAlertOverlay.coords[0].toFixed(5)}°N, {sosAlertOverlay.coords[1].toFixed(5)}°E
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Dispatched Agency:</span>
                <span className="text-white font-medium">Uttarakhand SDRF &amp; DDMA Quick Dispatch</span>
              </div>
            </div>

            <div className="mt-6 flex flex-col sm:flex-row items-center justify-center gap-3">
              <a
                href="tel:1070"
                className="w-full sm:w-auto px-6 py-3 rounded-xl bg-red-600 hover:bg-red-500 text-white font-extrabold text-xs tracking-wider shadow-lg shadow-red-700/50 flex items-center justify-center gap-2 cursor-pointer"
              >
                <PhoneCall className="w-4 h-4" />
                <span>Call SDRF Uttarakhand (1070)</span>
              </a>

              <button
                type="button"
                onClick={() => setSosAlertOverlay(null)}
                className="w-full sm:w-auto px-6 py-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 font-bold text-xs cursor-pointer"
              >
                Dismiss Overlay
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* MODAL: MOCK AUTHENTICATION MODAL                               */}
      {/* ============================================================== */}
      {isAuthModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="relative w-full max-w-md bg-[#0a1122] rounded-3xl border border-slate-700/80 p-6 md:p-8 shadow-2xl overflow-hidden">
            <div className="flex items-center justify-between mb-5">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-slate-800/80 border border-slate-700 flex items-center justify-center text-emerald-400 shadow">
                  <Lock className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-['Plus_Jakarta_Sans',sans-serif] text-lg font-bold text-white">
                    Mission Control Authentication
                  </h3>
                  <p className="text-[11px] text-slate-400">GarudaResQ Dehradun Tactical Access</p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setIsAuthModalOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2 bg-slate-950 p-1.5 rounded-xl border border-slate-800 mb-5">
              <button
                type="button"
                onClick={() => {
                  setTargetAuthRole('ngo');
                  setAuthUsername('ngo_admin');
                  setAuthPassword('resq123');
                  setAuthError('');
                }}
                className={`py-2 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                  targetAuthRole === 'ngo'
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <HeartHandshake className="w-4 h-4" />
                <span>NGO Operations</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setTargetAuthRole('shelter');
                  setAuthUsername('shelter_dehradun');
                  setAuthPassword('safe123');
                  setAuthError('');
                }}
                className={`py-2 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                  targetAuthRole === 'shelter'
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <ShieldCheck className="w-4 h-4" />
                <span>Shelter Incharge</span>
              </button>
            </div>

            {/* Credentials Hint Card */}
            <div className="bg-slate-900/90 rounded-xl p-3.5 border border-slate-800 mb-5 text-xs">
              <div className="text-[11px] font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1 mb-1">
                <Sparkles className="w-3 h-3" />
                <span>Demo Credentials Hint</span>
              </div>
              {targetAuthRole === 'ngo' ? (
                <div className="font-mono text-slate-300 space-y-0.5">
                  <div>ID: <span className="text-white font-bold">ngo_admin</span></div>
                  <div>Password: <span className="text-white font-bold">resq123</span></div>
                </div>
              ) : (
                <div className="font-mono text-slate-300 space-y-0.5">
                  <div>ID: <span className="text-white font-bold">shelter_dehradun</span></div>
                  <div>Password: <span className="text-white font-bold">safe123</span></div>
                </div>
              )}
            </div>

            <form onSubmit={handleLoginSubmit} className="space-y-4">
              {authError && (
                <div className="p-3 rounded-xl bg-red-950/80 border border-red-800 text-red-200 text-xs flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0 text-red-400" />
                  <span>{authError}</span>
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  {targetAuthRole === 'ngo' ? 'NGO Commander ID' : 'Shelter Facility ID'}
                </label>
                <input
                  type="text"
                  value={authUsername}
                  onChange={(e) => setAuthUsername(e.target.value)}
                  required
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-emerald-500 text-white text-xs font-mono outline-none"
                  placeholder="Enter User ID"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">Passcode / Token</label>
                <input
                  type="password"
                  value={authPassword}
                  onChange={(e) => setAuthPassword(e.target.value)}
                  required
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-emerald-500 text-white text-xs font-mono outline-none"
                  placeholder="Enter Passcode"
                />
              </div>

              <div className="pt-2 flex items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={() => {
                    if (targetAuthRole === 'ngo') {
                      setAuthUsername('ngo_admin');
                      setAuthPassword('resq123');
                    } else {
                      setAuthUsername('shelter_dehradun');
                      setAuthPassword('safe123');
                    }
                  }}
                  className="text-xs text-slate-400 hover:text-slate-200 underline font-medium cursor-pointer"
                >
                  Auto-Fill Demo
                </button>

                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs tracking-wide shadow-lg shadow-emerald-700/20 transition-all flex items-center gap-2 cursor-pointer"
                >
                  <LogIn className="w-4 h-4" />
                  <span>Sign In &amp; Launch</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* FOOTER                                                         */}
      {/* ============================================================== */}
      <footer className="bg-[#030712] border-t border-slate-800/80 py-4 px-4 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-400">GarudaResQ • Dehradun Region</span>
            <span>|</span>
            <span>Interactive Road Navigation &bull; Live Telemetry Sync</span>
          </div>
          <div>
            Built with Fullscreen Open Maps &bull; Google Maps Location Dot &bull; Dual SOS Engine
          </div>
        </div>
      </footer>
    </div>
  );
}
